# China to ban ivory trade

**HONG KONG** — It could be the beginning of the end for the illicit trade in ivory.

Last month, on a state visit to Washington, Chinese President Xi Jinping promised to stop the commercial trade in ivory in his country but gave few details about the timing and extent of such a move.

Now, a senior U.S. government official says that the Chinese ban could be in place within a year or so, with very narrow exceptions, describing it as a “huge” deal.

Such a move, conservationists say, would be a major step toward ending the poaching crisis that is decimating Africa’s elephant herds.
