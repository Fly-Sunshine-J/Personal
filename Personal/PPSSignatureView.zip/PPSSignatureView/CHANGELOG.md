# PPSSignatureView CHANGELOG

## 0.1.1

Fix iOS8 / XCode 6 errors

## 0.1.0

Initial release.
