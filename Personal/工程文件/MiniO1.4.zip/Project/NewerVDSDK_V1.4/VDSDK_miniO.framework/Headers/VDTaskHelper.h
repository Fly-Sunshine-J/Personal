//
//  VDTaskHelper.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/17.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>

@class VDResultData;
@class VDSessionParamsManager;

@protocol VDTaskDelegate;

@interface VDTaskHelper : NSObject

/**
 * 自然语言对话 导航 音乐 指令等  开始录音,对话
 * @param delegate          代理
 * @param longitude         经度  导航时需要
 * @param latitude          纬度  导航时需要
 * @param isShowView        是否显示录音界面
 */
- (void)beginVDTaskWithDelegate:(id<VDTaskDelegate>)delegate
                      longitude:(double)longitude
                       latitude:(double)latitude
                     isShowView:(bool)isShowView
                         params:(VDSessionParamsManager *)params;

//对象释放或者重新开始会话前需调用此方法取消会话
- (void)CancleSession;

@end

//VDTask的代理方法 与TaskDelegate类似
@protocol VDTaskDelegate <NSObject>

- (void)VDTaskInitResult:(NSString *)resultJson; //初始化结果
- (void)VDTaskResultJson:(NSString *)resultJson; //返回结果 结果参考文档

@optional

- (void)VDTaskBeginError:(NSInteger)result; //初始化失败信息 结果参考文档
- (void)VDTaskError:(NSInteger)result; //返回错误信息 结果参考文档

- (void)VDTaskBeginRecord; //返回开始录音标志
- (void)VDTaskEndRecord; //返回结束录音标志

- (void)VDTaskVolume:(NSInteger)currentvolume; //返回音量标志
- (void)VDTaskResult:(VDResultData*)result; //返回结果 结果类型参考文档

- (void)VDTaskFinishAll; //行为结束,可以释放当前对象资源

@end


