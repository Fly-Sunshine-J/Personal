//
//  VDFeedBackHelper.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/17.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>

@class VDResultData;
@class VDSessionParamsManager;

@protocol VDFeedbackDelegate;

@interface VDFeedBackHelper : NSObject

/**
 * 自然语言 意见反馈 吐槽
 * @param delegate          代理
 * @param isShowView        是否显示录音界面
 */
- (void)beginFeedbackWithDelegate:(id<VDFeedbackDelegate>)delegate
                        longitude:(double)longitude
                         latitude:(double)latitude
                       isShowView:(bool)isShowView
                           params:(VDSessionParamsManager *)params;

//对象释放或者重新开始会话前需调用此方法取消会话
- (void)CancleSession;

@end


//意见反馈的代理方法 与TaskDelegate类似
@protocol VDFeedbackDelegate <NSObject>

- (void)FeedbackInitResult:(NSString *)resultJson; //初始化结果
- (void)FeedbackResultJson:(NSString *)resultJson; //返回结果 结果参考文档

@optional

- (void)FeedbackBeginError:(NSInteger)result; //初始化失败信息 结果参考文档
- (void)FeedbackError:(NSInteger)result; //返回错误信息 结果参考文档

- (void)FeedbackBeginRecord; //返回开始录音标志
- (void)FeedbackEndRecord; //返回结束录音标志

- (void)FeedbackVolume:(NSInteger)currentvolume; //返回音量标志
- (void)FeedbackResult:(VDResultData *)result; //返回结果 结果类型参考文档

- (void)FeedbackFinishAll; //行为结束,可以释放当前对象资源

@end