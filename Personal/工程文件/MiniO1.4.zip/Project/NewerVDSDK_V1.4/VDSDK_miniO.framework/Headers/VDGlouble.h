#pragma once

#define VCYBER_AUDIO_FIRST		1
#define VCYBER_AUDIO_CONTINUE	2
#define	VCYBER_AUDIO_LAST		3

#define SPEEX_MODEID_NB 0
#define SPEEX_MODEID_WB 1
#define SPEEX_MODEID_UWB 2

#define CYV_MAX_BUFFER_SIZE_TOKEN			50				//会话标识缓冲区最大长度
#define CYV_MAX_BUFFER_SIZE_RESULT			1024			//识别结果缓冲区最大长度
#define CYV_MAX_BUFFER_SIZE_PARAMS			1024			//会话参数缓冲区最大长度
#define CYV_MAX_BUFFER_SIZE_AUDIO			1024 * 200		//语音数据缓冲区最大长度

//识别所处的状态
#define CYV_ASR_STATUS_IN_PROCESS			0				//识别正在进行中
#define CYV_ASR_STATUS_RETRIEVED			1				//可以检索识别结果
#define	CYV_ASR_STATUS_NO_MATCH				2				//识别结束，没有匹配的结果
#define CYV_ASR_STATUS_NO_SPEECH			3				//没有检测到语音
#define CYV_ASR_STATUS_COMPLETE				4				//识别结束
#define CYV_ASR_STATUS_DISCERN				5				//语音开始识别正在进行中
//#define CYV_ASR_STATUS_FAILED				6				//语音识别失败


//错误列表
#define CYV_SUCCESS								0			//成功


#define CYV_ERR_SYSTEM_FAILED					10001		//系统错误
#define CYV_ERR_INVALID_PARAM					10002       //无效的参数
#define CYV_ERR_NO_SUCH_GRAMMAR_SERVER			10003       //无可用的语法服务器
#define CYV_ERR_REQUEST_ALREADY_EXISTED			10004       //识别请求已存在
#define CYV_ERR_REQUEST_NO_EXISTED				10005       //识别请求不存在
#define CYV_ERR_REQUEST_TIMEOUT					10006       //识别请求超时
#define CYV_ERR_REQUEST_INVALID_STATUS			10007       //识别请求状态无效
#define CYV_ERR_ALREADY_LAST_SPEECH				10008       //已经存在最后的音频
#define CYV_ERR_PART_GRAMMAR_SERVER_UNAVAILABLE 10009		//有部分语法服务器不可用
#define CYV_ERR_NET_ACCESS_FAILED				10010		//网络访问失败

#define CYV_ERR_WRONG_STATE						20000		//错误的状态
#define CYV_ERR_AUTH_FAILED						20001		//鉴权失败
#define CYV_ERR_WRONG_VERSION					20002		//版本错误
#define CYV_ERR_DECODE_FAILED					20003		//数据不能解压
#define CYV_ERR_SEND_INVALID					20004		//发送的数据无效
#define CYV_ERR_OUT_AUDIO						20005		//音频超长

#define CYV_ERR_NULL_POINTER							21000
#define CYV_ERR_INVALID_CONFIG							21001
#define CYV_ERR_INVALID_XML								21002
#define CYV_ERR_FAIL_ENCODE								21003
#define CYV_ERR_INVALID_URL								21004
#define CYV_ERR_OPEN_FAIL								21005
#define CYV_ERR_CONN_TIMEOUT							21006
#define CYV_ERR_SEND_FAIL								21007
#define CYV_ERR_SET_FAIL								21008
#define CYV_ERR_SOCKET_FAIL								21009


#define CYV_CANCEL     30000 //用户取消操作
#define CYV_ERR_RECEIVEAUDIO     30001 //没有返回音频
#define CYV_ERR_RECEIVEDATA      30002  //没有返回数据
#define CYV_SILK_ERROR     30003 //音频压缩出现问题

#define CYV_SILK_ENCODE_ERROR     40001     //音频压缩出错
#define CYV_SILK_DECODE_ERROR     40002     //音频解压缩出错

#define CYV_ERROR_SERVEURL        40003     //服务器地址为空
#define CYV_APPKEY_ISNULL         40004     //语音识别引擎appkey为空
#define CYV_APPKEY_INVALID        40005     //语音识别引擎appkey无效


#define CYV_ERROR_SESSIONID_UNAVAILABLE  10205      //无可用SessionID
#define CYV_ERR_NO_SUCH_SESSION          10206      //找不到此会话

#define CYV_BEGINRECORD_ERROR     40006   //录音启动失败

