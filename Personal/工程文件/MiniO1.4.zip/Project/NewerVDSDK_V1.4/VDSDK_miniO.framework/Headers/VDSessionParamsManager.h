//
//  VDSessionParamsManager.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VDSessionParamsManager : NSObject

@property (nonatomic, assign) BOOL isShowView;          //是否显示默认音频波动视图界面

@property (nonatomic, copy) NSString *telNumber;        //电话号码

@property (nonatomic, assign) BOOL isPlayTTS;           //是否播放TTS
@property (nonatomic, assign) NSInteger maxVoice;       //最大录音时间
@property (nonatomic, assign) NSInteger timeOut;        //超时时间
@property (nonatomic, assign) NSInteger quality;        //音频质量
@property (nonatomic, copy) NSString *voiceK;           //录音灵敏度系数, 1.0~2.0 ,未设置, 默认1.0, 超出该范围设为默认
@property (nonatomic, copy) NSString *serverUrl;        //服务器地址
@property (nonatomic, copy) NSString *appId;            //语音识别引擎appkey
@property (nonatomic, copy) NSString *userId;           //用户名
@property (nonatomic, assign) NSInteger audioFormat;    //录音采样率 1:8000 ; 2:16000 ,建议值2, 可不做改变
@property (nonatomic, assign) NSInteger compressModel;  //压缩模型 可不做改变

@property (nonatomic, assign, readonly) NSInteger sampleBits;
@property (nonatomic, assign, readonly) NSInteger noiseReduce;
@property (nonatomic, copy, readonly) NSString *TTS;

@end