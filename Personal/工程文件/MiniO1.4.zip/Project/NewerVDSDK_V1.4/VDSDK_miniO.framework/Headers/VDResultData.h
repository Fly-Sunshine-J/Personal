//
//  VDResultData.h
//  VD_V1.3_Demo
//
//  Created by dengweihao on 16/3/23.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VDResultData : NSObject

@property (nonatomic, copy) NSNumber *error;        //返回错误码
@property (nonatomic, copy) NSNumber *status;       //返回状态码
@property (nonatomic, copy) NSString *text;         //文本信息
@property (nonatomic, copy) NSNumber *textLength;   //文本信息长度
@property (nonatomic, copy) NSString *type;         //类型
@property (nonatomic, copy) NSNumber *audioLenth;   //音频长度
@property (nonatomic, copy) NSString *base64Audio;  //压缩的base64音频数据
@property (nonatomic, copy) NSData   *audio;        //音频数据

@end
