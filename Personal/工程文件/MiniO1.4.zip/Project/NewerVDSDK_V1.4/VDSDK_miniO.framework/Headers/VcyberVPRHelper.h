//
//  VcyberVPRHelper.h
//  ZingVPRFramework
//
//  Created by danhui.quan on 15/2/2.
//  Copyright (c) 2015年 vcyber. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^VPRCallBack)(bool isSuccess, NSData *data, NSString *errorMessage);


@interface VcyberVPRHelper : NSObject

/**
 *  文字转TTS
 *  @param text 转换的文本
 *  @param callBackBlock 回调
 */
- (void)textToTTSWithText:(NSString *)text callBack:(VPRCallBack)callBack;


@end

