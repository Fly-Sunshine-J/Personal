//
//  ViewController.h
//  NewerVDSDK
//
//  Created by dengweihao on 15/12/25.
//  Copyright © 2015年 dengweihao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <VDSDK_miniO/VDSDK_miniO.h>

@interface ViewController : UIViewController


@end

