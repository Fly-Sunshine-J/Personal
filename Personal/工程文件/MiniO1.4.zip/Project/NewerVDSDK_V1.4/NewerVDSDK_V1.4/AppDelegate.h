//
//  AppDelegate.h
//  NewerVDSDK_V1.3
//
//  Created by dengweihao on 16/3/18.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

