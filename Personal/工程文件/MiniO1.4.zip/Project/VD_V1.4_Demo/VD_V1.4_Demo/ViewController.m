//
//  ViewController.m
//  NewerVDSDK
//
//  Created by dengweihao on 15/12/25.
//  Copyright © 2015年 dengweihao. All rights reserved.
//

#import "ViewController.h"


#define TestURL1 @"http://ajxvd.vcyber.com:10006"
#define TestURL2 @"http://ajxvd.vcyber.com:10007"

#import <AVFoundation/AVFoundation.h>


@interface ViewController ()<VDTaskDelegate, VDFeedbackDelegate, UITextFieldDelegate, UIAlertViewDelegate>

@property (nonatomic, strong) NSArray *arrayData;

@property (nonatomic, strong) VDTaskHelper *vdTaskHelper;
@property (nonatomic, strong) VDFeedBackHelper *feedBackHelper;

@property (nonatomic, strong) VcyberVPRHelper *VPRhelper;

@property (weak, nonatomic) IBOutlet UITextView *messageView;
@property (weak, nonatomic) IBOutlet UITextField *userIdTextField;
@property (weak, nonatomic) IBOutlet UITextField *VoiceKTextField;

/** update at 2016年04月27日19:52:17 */
@property (weak, nonatomic) IBOutlet UITextField *TTSTextField;

@property (weak, nonatomic) IBOutlet UITableView *SessionTableView;
@property (weak, nonatomic) IBOutlet UITextField *VDHostUrlTextField;
@property (weak, nonatomic) IBOutlet UITextField *FeedBackHostUrlTextField;
@property (weak, nonatomic) IBOutlet UITextView *TestMessageView; //测试
@property (weak, nonatomic) IBOutlet UIButton *clearCacheBtn;

@property (nonatomic, strong) AVAudioPlayer *player;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"VDHostName"]) {
        _VDHostUrlTextField.text = [defaults objectForKey:@"VDHostName"];
    }
    if ([defaults objectForKey:@"FeedBackHostName"]) {
        _FeedBackHostUrlTextField.text = [defaults objectForKey:@"FeedBackHostName"];
    }
    if ([defaults objectForKey:@"VDUserID"]) {
        _userIdTextField.text = [defaults objectForKey:@"VDUserID"];
    }
    if ([defaults objectForKey:@"VoiceK"]) {
        _VoiceKTextField.text = [defaults objectForKey:@"VoiceK"];
    }
    if ([defaults objectForKey:@"TTSText"]) { /** update at 2016年04月27日19:52:18 */
        _TTSTextField.text = [defaults objectForKey:@"TTSText"];
    }
    
    _userIdTextField.returnKeyType = UIReturnKeyYahoo;
    
    _arrayData = [NSArray arrayWithObjects:[NSString stringWithFormat:@"VD/自然语音对话--%@", _VDHostUrlTextField.text], [NSString stringWithFormat:@"Feedback/意见反馈 吐槽--%@", _FeedBackHostUrlTextField.text], @"textToTTS/文本转语音", nil];
//    _arrayData = [NSArray arrayWithObjects:@"VD/自然语音对话", @"Feedback/意见反馈 吐槽", @"CheckAuthorization/检查注册",@"TrainVoiceCommandModel/文本无关建模",@"VerifyVoiceCommandModel/文本无关验证",@"TrainVPRMod/文本相关建模",@"VerifyVPRMod/文本相关验证", @"RemoveMod/删除模型", @"textToTTS/文本转语音", @"QuerySite/查询地点信息", nil];
    _vdTaskHelper = [[VDTaskHelper alloc] init];
    _feedBackHelper = [[VDFeedBackHelper alloc] init];
    
    _VPRhelper = [[VcyberVPRHelper alloc] init];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 1) {
        if (buttonIndex == 1) {
            [self doCleanCache];
        }
    }
}

- (IBAction)clearCache:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"是否清除缓存?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alert.tag = 1;
    [alert show];
}

- (void)doCleanCache {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *DocumentsDirectory = [paths objectAtIndex:0];
    NSString *audioFilePath = [DocumentsDirectory stringByAppendingFormat:@"/TTS&Record/"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL fileExists = [fileManager fileExistsAtPath:audioFilePath];
    if (fileExists)
    {
        [fileManager removeItemAtPath:audioFilePath error:nil];
        [self showJson:@"缓存已清除"];
    } else {
        [self showJson:@"没有缓存......无需清除"];
    }
}

#pragma mark tableView代理方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _arrayData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *indentifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indentifier];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
    }
    
    cell.textLabel.text = [_arrayData objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self pickUPKeyBoard];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 0) { //自然语音对话 导航
        [self beginVDTask];
    }
    if (indexPath.row == 1) { //意见反馈 吐槽
        [self beginFeedBack];
    }
    if (indexPath.row == 2) { //文本转为TTS声音
        NSString *text = _TTSTextField.text;
        [_VPRhelper textToTTSWithText:text
                             callBack:
         ^(bool isSuccess, NSData *data, NSString *errorMessage) {
             if (isSuccess) {
                 
                 _player = [[AVAudioPlayer alloc] initWithData:data error:nil];
                 [_player prepareToPlay];
                 [_player play];
                 
                 NSURL *cachesURL = [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
                 NSLog(@"audio url: %@",[cachesURL URLByAppendingPathComponent:@"latestTTS.wav"]);
                 cachesURL = [cachesURL URLByAppendingPathComponent:@"latestTTS.wav"];
                 
                 [data writeToFile:cachesURL.path atomically:YES];
                 
             }else{
                 UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"failure"
                                                                     message:errorMessage
                                                                    delegate:nil
                                                           cancelButtonTitle:@"OK"
                                                           otherButtonTitles:nil];
                 [alertView show];
             }
         }];
        
    }
}

#pragma mark - Task
- (IBAction)NaviBtn:(id)sender {
    NSLog(@"点击导航按钮");
    [self beginVD:TestURL1];
}

- (IBAction)commandBtn:(id)sender {
    NSLog(@"点击命令按钮");
    [self beginVD:TestURL1];
}

- (IBAction)weatherBtn:(id)sender {
    NSLog(@"点击天气按钮");
    [self beginVD:TestURL1];
}

- (IBAction)feedBackBtn:(id)sender {
    NSLog(@"点击吐槽按钮");
    [self beginFeedBack:TestURL2];
}

- (void)beginVD:(NSString *)hostUrl {
    NSString *voiceK = _VoiceKTextField.text;
    NSString *telNumber = _userIdTextField.text;
    
    VDSessionParamsManager *params = [[VDSessionParamsManager alloc] init];
    params.serverUrl = hostUrl; //正式环境无效, 不用设置
    params.telNumber = telNumber;
    params.isPlayTTS = YES;
    params.maxVoice = 10;
    params.timeOut = 30;
    params.quality = 10;
    params.voiceK = voiceK;
    
    [_vdTaskHelper beginVDTaskWithDelegate:self
                                 longitude:0
                                  latitude:0
                                isShowView:YES
                                    params:params];
}

- (void)beginFeedBack:(NSString *)hostUrl {
    NSString *voiceK = _VoiceKTextField.text;
    NSString *telNumber = _userIdTextField.text;
    
    VDSessionParamsManager *params = [[VDSessionParamsManager alloc] init];
    params.serverUrl = hostUrl; //正式环境无效, 不用设置
    params.telNumber = telNumber;
    params.isPlayTTS = YES;
    params.maxVoice = 10;
    params.timeOut = 30;
    params.quality = 10;
    params.voiceK = voiceK;
    
    [_feedBackHelper beginFeedbackWithDelegate:self
                                     longitude:0
                                      latitude:0
                                    isShowView:YES
                                        params:params];
}

- (void)beginVDTask {
    
    NSString *VDHostUrl = _VDHostUrlTextField.text;
    [self beginVD:VDHostUrl];
}

- (void)beginFeedBack {
    NSString *FeedBackHostUrl = _FeedBackHostUrlTextField.text;
    [self beginFeedBack:FeedBackHostUrl];
}

#pragma mark
#pragma mark - VDTaskDelegate
//初始化结果
- (void)VDTaskInitResult:(NSString *)resultJson
{
    NSLog(@"%@", resultJson);
    [self showJson:resultJson];
}

//返回结果 结果参考文档
- (void)VDTaskResultJson:(NSString *)resultJson
{
    NSLog(@"%@", resultJson);
    [self showJson:resultJson];
}

//初始化失败信息 结果参考文档
- (void)VDTaskBeginError:(NSInteger)result
{
    NSLog(@"VDTaskBeginError The error is %ld",(long)result);
}

//返回错误信息 结果参考文档
- (void)VDTaskError:(NSInteger)result
{
    NSLog(@"VDTaskError The error is %ld",(long)result);
}

//返回开始录音标志
- (void)VDTaskBeginRecord
{
    NSLog(@"VDTaskBeginRecord");
}

//返回结束录音标志
- (void)VDTaskEndRecord
{
    NSLog(@"VDTaskEndRecord");
}

//返回音量标志
- (void)VDTaskVolume:(NSInteger)currentvolume
{
//    NSLog(@"VDTaskVPRVolume the volume is %ld", (long)currentvolume);
}

//返回结果 结果类型参考文档
- (void)VDTaskResult:(VDResultData *)result
{
    NSLog(@"The result is %@", result.text);
    NSLog(@"The result type is %@", result.type);
}

//行为结束,可以释放当前对象资源
- (void)VDTaskFinishAll
{
    NSLog(@"VDTaskFinishAll");
}

#pragma mark
#pragma mark VDFeedbackDelegate

//初始化结果返回
- (void)FeedbackInitResult:(NSString *)resultJson
{
    NSLog(@"%@", resultJson);
    [self showJson:resultJson];
}

//执行结果返回, JSON数据
- (void)FeedbackResultJson:(NSString *)resultJson
{
    NSLog(@"%@", resultJson);
    [self showJson:resultJson];
}

- (void)FeedbackBeginError:(NSInteger)result {
    NSLog(@"FeedbackBeginError The error is %ld",(long)result);
}

- (void)FeedbackError:(NSInteger)result{
    NSLog(@"FeedbackError The error is %ld",(long)result);
}

- (void)FeedbackBeginRecord {
    NSLog(@"FeedbackBeginRecord");
}

- (void)FeedbackEndRecord {
    NSLog(@"FeedbackEndRecord");
}

- (void)FeedbackVolume:(NSInteger)currentvolume {
//    NSLog(@"FeedbackVolume the volume is %ld", (long)currentvolume);
}

//执行结果返回, VDResultData数据
- (void)FeedbackResult:(VDResultData *)result {
    NSLog(@"The result is %@", result.text);
    NSLog(@"The result type is %@", result.type);
}

- (void)FeedbackFinishAll { //行为结束,可以释放当前对象资源
    NSLog(@"VDTaskVPRFinishAll");
}

#pragma mark - show Message

- (void)showJson:(NSString *)resultJson
{
    dispatch_async(dispatch_get_main_queue(), ^{
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yy-MM-dd HH:mm:ss"];
        NSString *string = [[NSString alloc] initWithFormat:@"%@ %@\n",[formatter stringFromDate:[NSDate date]],resultJson];
        _messageView.text = [_messageView.text stringByAppendingString:string];
        [self performSelector:@selector(textViewScrollToBottom) withObject:nil afterDelay:0.01];
    });
}

- (void)textViewScrollToBottom
{
    dispatch_async(dispatch_get_main_queue(), ^{
        CGRect rect = [self.messageView caretRectForPosition:self.messageView.endOfDocument];
        [self.messageView scrollRectToVisible:rect animated:NO];
    });
}

#pragma mark -
#pragma mark -

- (void)pickUPKeyBoard {
    [self.view endEditing:YES];
    [_VDHostUrlTextField resignFirstResponder];
    [_FeedBackHostUrlTextField resignFirstResponder];
}

- (IBAction)rightBarClicked:(id)sender {
    [self pickUPKeyBoard];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"回收键盘");
    [self pickUPKeyBoard];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self pickUPKeyBoard];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (textField == _VDHostUrlTextField || textField == _FeedBackHostUrlTextField) {
        [defaults setObject:_VDHostUrlTextField.text forKey:@"VDHostName"];
        [defaults setObject:_FeedBackHostUrlTextField.text forKey:@"FeedBackHostName"];
        
        _arrayData = [NSArray arrayWithObjects:[NSString stringWithFormat:@"VD/自然语音对话--%@", _VDHostUrlTextField.text], [NSString stringWithFormat:@"Feedback/意见反馈 吐槽--%@", _FeedBackHostUrlTextField.text], nil];
        [_SessionTableView reloadData];
    }
    if (textField == _userIdTextField) {
        [defaults setObject:_userIdTextField.text forKey:@"VDUserID"];
    }
    if (textField == _VoiceKTextField) {
        [defaults setObject:_VoiceKTextField.text forKey:@"VoiceK"];
    }
    if (textField == _TTSTextField) { /** update at 2016年04月27日19:52:19 */
        [defaults setObject:_TTSTextField.text forKey:@"TTSText"];
    }
    
    [defaults synchronize];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
