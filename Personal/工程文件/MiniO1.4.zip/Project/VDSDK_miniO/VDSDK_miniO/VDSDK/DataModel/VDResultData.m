//
//  VDResultData.m
//  VD_V1.3_Demo
//
//  Created by dengweihao on 16/3/23.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "VDResultData.h"

@implementation VDResultData

@end