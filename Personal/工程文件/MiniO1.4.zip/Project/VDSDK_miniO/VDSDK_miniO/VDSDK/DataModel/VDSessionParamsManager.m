//
//  VDSessionParamsManager.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "VDSessionParamsManager.h"

@implementation VDSessionParamsManager

- (instancetype)init {
    if (self = [super init]) {
        _serverUrl = @"http://10.1.8.166:10006"; //测试服务器地址
        _telNumber = @"";
        _isShowView = YES;
        _isPlayTTS = YES;
        _maxVoice = 10;
        _timeOut = 30;
        _quality = 10;
        
        _userId = @"guest";
        _audioFormat = 2;
        _compressModel = 3;
        
        _sampleBits = 16;
        _noiseReduce = 2;
        _TTS = @"true";
        
        _voiceK = @"1";
    }
    return self;
}

@end