//
//  URLEncodeUtil.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/14.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "URLEncodeUtil.h"

@implementation URLEncodeUtil

+ (void)URLEncode:(NSString *)originalString OutStr:(NSString **)outstr {
    NSArray * escapeChars = [[NSArray alloc ] initWithObjects:@";" , @"/" , @"?" , @":" ,
                             @"@" , @"&" , @"=" , @"+" ,    @"$" , @"," ,
                             @"!", @"'", @"(", @")", @"*", nil];
    
    NSArray *replaceChars = [[NSArray alloc] initWithObjects:@"%3B" , @"%2F", @"%3F" , @"%3A" ,
                             @"%40" , @"%26" , @"%3D" , @"%2B" , @"%24" , @"%2C" ,
                             @"%21", @"%27", @"%28", @"%29", @"%2A", nil];
    
    NSUInteger len = [escapeChars count];
    
    NSMutableString * temp =[[NSMutableString alloc] initWithString: [originalString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    int i;
    for (i = 0; i < len; i++) {
        
        [temp replaceOccurrencesOfString:[escapeChars objectAtIndex:i]
                              withString:[replaceChars objectAtIndex:i]
                                 options:NSLiteralSearch
                                   range:NSMakeRange(0, [temp length])];
    }
    *outstr = temp ;
    temp = nil;
}

@end
