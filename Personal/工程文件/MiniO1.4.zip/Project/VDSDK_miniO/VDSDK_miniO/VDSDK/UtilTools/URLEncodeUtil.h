//
//  URLEncodeUtil.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/14.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface URLEncodeUtil : NSObject

+ (void)URLEncode:(NSString *)originalString OutStr:(NSString **)outstr;

@end
