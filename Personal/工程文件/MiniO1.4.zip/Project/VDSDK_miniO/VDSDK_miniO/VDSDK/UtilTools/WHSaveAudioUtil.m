//
//  WHSaveAudioUtil.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "WHSaveAudioUtil.h"
#import "VDCommon.h"

@implementation WHSaveAudioUtil

+ (void)WHWriteDataToFile:(NSData *)fileData FileType:(NSString *)fileType {
    NSString *fileDataPath = [[self WHGetAudioFilePath] stringByAppendingString:[NSString stringWithFormat:@"%@ %@", [self WHGetDateStr], fileType]];
    VcyberLog(@"TTSDataPath: %@", fileDataPath);
    [fileData writeToFile:fileDataPath atomically:YES];
}

+ (void)WHWriteTTSDataToFile:(NSData *)TTSData {
    NSString *TTSDataPath = [[self WHGetAudioFilePath] stringByAppendingString:[NSString stringWithFormat:@"%@ TTS.wav", [self WHGetDateStr]]];
    VcyberLog(@"TTSDataPath: %@", TTSDataPath);
    [TTSData writeToFile:TTSDataPath atomically:YES];
}

+ (void)WHWriteRecordDataToFile:(NSData *)RecondData {
    NSString *RecondDataPath = [[self WHGetAudioFilePath] stringByAppendingString:[NSString stringWithFormat:@"%@ REC.wav", [self WHGetDateStr]]];
    VcyberLog(@"RecondDataPath: %@", RecondDataPath);
    [RecondData writeToFile:RecondDataPath atomically:YES];
}

+ (NSString *)WHGetDocumentPath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    return [paths objectAtIndex:0];
}

+ (NSString *)WHGetDateStr
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"]];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateStr = [formatter stringFromDate:[NSDate date]];
    return dateStr;
}

+ (NSString *)WHGetAudioFilePath
{
    NSString *audioFilePath = [[self WHGetDocumentPath] stringByAppendingFormat:@"/TTS&Record/"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL fileExists = [fileManager fileExistsAtPath:audioFilePath];
    if (!fileExists)
    {
        [fileManager createDirectoryAtPath:audioFilePath  withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return audioFilePath;
}

@end
