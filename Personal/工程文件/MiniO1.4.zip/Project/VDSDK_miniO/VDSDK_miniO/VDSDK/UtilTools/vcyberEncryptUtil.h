//
//  vcyberEncryptUtil.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface vcyberEncryptUtil : NSObject

+ (NSString *)EncryptPefect:(NSString *)encrypt key:(NSString *)key;

+ (char *)Base64Encode:(unsigned char *)pIn  nInLen:(int)nInLen;

+ (NSData *)AddHeader:(NSData *)pcmdata Channels:(int)channels LongSampleRate:(int)longSampleRate ByteRate:(int)byteRate;

@end
