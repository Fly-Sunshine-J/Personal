//
//  WHSaveAudioUtil.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WHSaveAudioUtil : NSObject

+ (void)WHWriteTTSDataToFile:(NSData *)TTSData; //将TTS数据写入沙盒目录(.wav)
+ (void)WHWriteRecordDataToFile:(NSData *)RecondData;   //将录音数据写入沙盒目录(.wav)

+ (void)WHWriteDataToFile:(NSData *)fileData FileType:(NSString *)fileType;

@end
