//
//  vcyberEncryptUtil.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "vcyberEncryptUtil.h"
#include <stdio.h>
#import <CommonCrypto/CommonCryptor.h>
#include <string.h>

@implementation vcyberEncryptUtil

+ (NSString *)EncryptPefect:(NSString *)encrypt key:(NSString *)key
{
    if(encrypt ==nil && [encrypt length] == 0 ) return nil;
    if(key ==nil && [key length]== 0 ) return nil;
    
    NSData* bytesencrypt =  [encrypt dataUsingEncoding:NSUTF8StringEncoding];
    NSData* bytesenkey = [key dataUsingEncoding:NSUTF8StringEncoding];
    
    Byte* pEncryptEncode =  (Byte *)[bytesencrypt bytes];
    Byte* pKeyEncode =  (Byte *)[bytesenkey bytes];
    
    //    Byte * pEncryPtValue = new Byte[[bytesencrypt length]];
    Byte pEncryPtValue[[bytesencrypt length]];
    
    for(int i=0,j=0; i<[bytesencrypt length]; i++,j++){
        pEncryPtValue[i] = pEncryptEncode[i] ^ pKeyEncode[j];
        if(j == [bytesenkey length] - 1) j = -1;
    }
    
    
    Byte hight = 0 , low =0;
    for(int k = 0; k<[bytesencrypt length] ; k++){
        hight = (Byte)((pEncryPtValue[k] &0xf0) >> 4 );
        low  = (Byte)((pEncryPtValue[k] &0x0f) << 4);
        pEncryPtValue[k] = (Byte)(hight|low);
    }
    
    NSString* hexStr = @"";
    for(int i = 0; i<[bytesencrypt length]; i++)
    {
        
        NSString *newHexStr = [NSString stringWithFormat:@"%x",pEncryPtValue[i]];
        
        if ([newHexStr length]==1){
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
            
        }else{
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
            
        }
        
    }
    //    free(pEncryPtValue);
    return hexStr;
}



+ (char *)Base64Encode:(unsigned char *)pIn  nInLen:(int)nInLen
{
    if(pIn == NULL || nInLen == 0) return NULL;
    
    //	const std::string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    char* base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    char* ret = malloc(2*nInLen+1);
    memset(ret,0,2*nInLen+1);
    char* p = ret;
    
    int i = 0;
    int j = 0;
    unsigned char char_array_3[3];
    unsigned char char_array_4[4];
    
    while (nInLen--) {
        char_array_3[i++] = *(pIn++);
        if (i == 3) {
            char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
            char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
            char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
            char_array_4[3] = char_array_3[2] & 0x3f;
            
            for(i = 0; (i <4) ; i++){
                *p = base64_chars[char_array_4[i]];
                p++;
            }
            
            i = 0;
        }
    }
    
    if (i)
    {
        char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
        char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
        char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
        char_array_4[3] = char_array_3[2] & 0x3f;
        
        for (j = 0; (j < i + 1); j++){
            //            ret += base64_chars[char_array_4[j]];
            *p = base64_chars[char_array_4[j]];
            p++;
        }
        
        while((i++ < 3)){
            //            ret += '=';
            *p = '=';
        }
        
        
    }
    
    return ret;
}

+ (NSData *)AddHeader:(NSData *)pcmdata Channels:(int)channels LongSampleRate:(int)longSampleRate ByteRate:(int)byteRate {
    if (nil == pcmdata)
    {
        return nil;
    }
    NSMutableData * mndata = [[NSMutableData alloc] init];
    Byte header[44] ;
    int pcmlen = (int)[pcmdata length];
    int totallen = pcmlen + 36;
    header[0] = 'R';
    header[1] = 'I';
    header[2] = 'F';
    header[3] = 'F';
    header[4] = totallen&0xff;
    header[5] = (totallen >> 8)&0xff;
    header[6] = (totallen >> 16)&0xff;
    header[7] = (totallen >> 24)&0xff;
    header[8] = 'W';
    header[9] = 'A';
    header[10] = 'V';
    header[11] = 'E';
    header[12] = 'f';
    header[13] = 'm';
    header[14] = 't';
    header[15] = ' ';
    header[16] = 16; //4bytes size of fmt chunk
    header[17] = 0;
    header[18] = 0;
    header[19] = 0;
    header[20] = 1; //format =1
    header[21] = 0;
    header[22] = channels;
    header[23] = 0;
    header[24] = longSampleRate & 0xff;
    header[25] = longSampleRate >> 8 & 0xff;
    header[26] = longSampleRate >> 16 & 0xff;
    header[27] = longSampleRate >> 24 & 0xff;
    header[28] = byteRate & 0xff;
    header[29] = byteRate >> 8 & 0xff;
    header[30] = byteRate >> 16 & 0xff;
    header[31] = byteRate >> 24 & 0xff;
    header[32] = channels*16/8;
    header[33] = 0;
    header[34] = 16; //recorder_bpp
    header[35] = 0;
    header[36] = 'd';
    header[37] = 'a';
    header[38] = 't';
    header[39] = 'a';
    header[40] = pcmlen & 0xff;
    header[41] = pcmlen >> 8 & 0xff;
    header[42] = pcmlen >> 16 & 0xff;
    header[43] = pcmlen >> 24 & 0xff;
    [mndata appendBytes:header length:44];
    [mndata appendData:pcmdata];
    return mndata;
    
}

@end
