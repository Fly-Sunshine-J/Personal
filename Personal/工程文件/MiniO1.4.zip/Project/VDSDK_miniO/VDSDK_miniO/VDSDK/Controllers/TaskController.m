//
//  TaskController.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//
#import "TaskController.h"
#import "VDRecordTask.h"

#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import "VDGlouble.h"
#import "VDCommon.h"

#import "HttpRequest.h"
#import "VDSessionParamsManager.h"
#import "VDSessionView.h"

#import "vcyberEncryptUtil.h"
#import "WHSaveAudioUtil.h"

#include <sys/time.h>

typedef NS_ENUM(NSInteger, VoiceType) {
    VoiceTypeWaiting,       //等待提示音
    VoiceTypeTTSPlay,       //播放TTS
    VoiceTypeErrorPlay,     //播放错误提示音
    VoiceTypeTTSOver,       //最后一次TTS播放
};

@interface TaskController ()<HttpRequestDelegate, AVAudioPlayerDelegate, VDRecordDelegate, VDSessionViewDelegate>

@property (nonatomic, strong) AVAudioPlayer *audioPlayer;//
@property (nonatomic, strong) VDSessionParamsManager *SessionParams;
@property (nonatomic, assign) NSInteger CurrentPlayStatus;
@property (nonatomic, strong) VDRecordTask *recordTask;

@property (nonatomic, assign) BOOL IsCancelTask;
@property (nonatomic, assign) BOOL Is16k;
@property (nonatomic, assign) BOOL IsPlayTTS;
@property (nonatomic, assign) NSInteger maxVoiceTime;

@property (nonatomic, strong) NSBundle *resourceBundle; //资源文件
@property (nonatomic, assign) double RecondVoiceK;  //录音灵敏度系数

@property (nonatomic, strong) HttpRequest *httpRequest;

@property (nonatomic, strong) NSMutableData *cacheRecordData;
@property (nonatomic, strong) VDSessionView *VDSessionView;

@end


@implementation TaskController

- (HttpRequest *)httpRequest {
    if (!_httpRequest) {
        _httpRequest = [[HttpRequest alloc] initWithSessionParams:self.SessionParams];
        VcyberLog(@"初始化http请求参数!");
    }
    return _httpRequest;
}

- (void)setSessionParams:(VDSessionParamsManager *)SessionParams {
    _SessionParams = SessionParams;
}

- (VDRecordTask *)rt {
    if (!_recordTask) {
        _recordTask = [[VDRecordTask alloc] init];
        [_recordTask AudioSessionInit:_Is16k MaxVoiceTime:_maxVoiceTime VoiceScale:_RecondVoiceK];
        _recordTask.delegate = self;
        VcyberLog(@"初始化录音成功");
    }
    return _recordTask;
}

- (instancetype)initWithSessionParam:(VDSessionParamsManager *)SessionParams {
    if (self = [self init]) {
        self.SessionParams = SessionParams;
        
        if (2 == SessionParams.audioFormat) {
            _Is16k = YES;
        } else {
            _Is16k = NO;
        }
        _IsPlayTTS = SessionParams.isPlayTTS;
        _maxVoiceTime = SessionParams.maxVoice;
        
        if (SessionParams.voiceK != nil) {
            _RecondVoiceK = [SessionParams.voiceK doubleValue];
        }
        VcyberLog(@"RecondVoiceK:%f", _RecondVoiceK);
        
        if (SessionParams.isShowView && _resourceBundle) {
            _VDSessionView = [[VDSessionView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
            _VDSessionView.Sdelegate = self;
            [[[UIApplication sharedApplication] keyWindow] addSubview:_VDSessionView];
        }
    }
    return self;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        VcyberLog(@"--初始化TaskController--");
        
        NSString * bundlePath = [[NSBundle mainBundle] pathForResource:@"Resource" ofType:@"bundle"];
        _resourceBundle = [NSBundle bundleWithPath:bundlePath];
        VcyberLog(@"ResourceBundle:%@", _resourceBundle);
    }
    return self;
}

- (void)reset {
    _IsCancelTask = NO;
}

/*初始化并执行线程*/
- (void)InitStartThread {
    
//    __darwin_time_t ret2 = [self getTimeOfNow];
//    
//    [[AVAudioSession sharedInstance] setActive:YES error:nil];
//    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:(AVAudioSessionCategoryOptionMixWithOthers|AVAudioSessionCategoryOptionDefaultToSpeaker) error:nil];
//    
//    __darwin_time_t ret3 = [self getTimeOfNow];
//    DPrint("setCategoryOptionTime %ld\n", ret3 - ret2);
    
    [self reset];
    
    (void)[self rt];
    [self beginRecordAndCallBack];
    
    if (_IsPlayTTS) {
        [self PlayVoice:VoiceTypeWaiting PlayData:nil];
    }
    
    VcyberLog(@"InitStartThread current cancel is %d", _IsCancelTask);
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self ThreadSession];
    });
}

- (void)CancleSession {
    _IsCancelTask = YES;
    if(_recordTask){
        [_recordTask SetCancle];
    }
    [self DismissView];
}

/*结束所有并释放资源*/
- (void)DismissView {
    VcyberLog(@"CancleSession current cancel is %d", _IsCancelTask);
    dispatch_async(dispatch_get_main_queue(), ^{
        [_VDSessionView removeFromSuperview];
    });
    
    if (_httpRequest) {
        [self.httpRequest httpSetCancel];
        VcyberLog(@"准备发送sessionEnd step1");
        [self.httpRequest httpSessionEnd];
    }
    
    if (_recordTask) {
        [_recordTask AudioSessionDispose];
    }
    
    if (_audioPlayer !=nil && _audioPlayer.isPlaying) {
        [_audioPlayer stop];

    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(CallBackFinishAll)]) {
        [self.delegate CallBackFinishAll];
    }

}

/*调用BEGINSESSION API接口*/
- (void)ThreadSession {
    @autoreleasepool {
        if (!_IsCancelTask) {
            
            self.httpRequest.delegate = self;
            // 启动语音识别会话
            [self.httpRequest httpSessionBegin];
            VcyberLog(@"启动语音识别会话!");
        }
    }
    
}

#pragma mark - SessionBegin回调

- (void)httpSessionBeginResult:(NSInteger)flag result:(VDResultData *)resultData {
    VcyberLog(@"httpSessionBeginResult: %d", (int)flag);
    if (_IsCancelTask) {
        return;
    }
    
    if (flag == 0 && !_IsCancelTask)
    {
        if ([resultData.audio length]>0)
        {
            NSData * voicedata = [[NSData alloc] initWithData:[vcyberEncryptUtil AddHeader:resultData.audio Channels:1 LongSampleRate:8000 ByteRate:16000]];
            if (_IsPlayTTS)
            {
                [self PlayVoice:VoiceTypeTTSPlay PlayData:voicedata];
            } else {
#if LogCtrol
                [self.cacheRecordData setData:[NSData data]];
#endif
                [_httpRequest resetAudioIndex];
//                [self beginRecordAndCallBack]; //开始录音并回调
                [_recordTask SetAudioValid];
            }
        } else {
            [self PlayVoice:VoiceTypeErrorPlay PlayData:nil];
            [self sendCallBackBeginError:CYV_ERR_RECEIVEAUDIO];
        }
    } else {
        if (!_IsCancelTask) {
            [self PlayVoice:VoiceTypeErrorPlay PlayData:nil];
            [self sendCallBackBeginError:flag];
        }
    }
}

// 初始化失败代理回调
- (void)sendCallBackBeginError:(NSInteger)errorCode {
    if (self.delegate && [self.delegate respondsToSelector:@selector(CallBackBeginError:)]) {
        [self.delegate CallBackBeginError:errorCode];
    }
}

#pragma mark - 播放声音功能实现

/*播放声音功能实现*/
- (void)PlayVoice:(VoiceType)voiceType PlayData:(NSData *)playdata
{
//    [[AVAudioSession sharedInstance] setActive:YES error:nil];
    VcyberLog(@"voiceType: %ld", (long)voiceType);
    
    if ([_audioPlayer isPlaying] && _audioPlayer!=nil) {
        VcyberLog(@"--停止音频--");
        [_audioPlayer stop];
        _audioPlayer = nil;
    }
    if (_IsCancelTask) {
        return;
    }
    _CurrentPlayStatus = voiceType;
    
    if (voiceType == VoiceTypeWaiting) {    //播放等待提示音
        [self playAudio:@"vcyber_harp"];
        VcyberLog(@"--播放等待提示音--");
    }
    
    if (voiceType == VoiceTypeTTSPlay || voiceType == VoiceTypeTTSOver) {  //播放TTS
        if (nil == playdata) {
            [self CancleSession];
        } else {
#if LogCtrol
            [WHSaveAudioUtil WHWriteTTSDataToFile:playdata];
#endif
            _audioPlayer = [[AVAudioPlayer alloc] initWithData:playdata error:nil];
            [self AudioPlayerStart];
            VcyberLog(@"--播放TTS--");
        }
    }
    
    if (voiceType == VoiceTypeErrorPlay) {  //播放错误提示音
        [self playAudio:@"vcyber_error"];
        VcyberLog(@"--播放错误提示音--");
    }
}

- (void)playAudio:(NSString *)AudioName {
    NSURL *AudioUrl = [[NSURL alloc] initFileURLWithPath:[NSString stringWithFormat:@"%@/%@.wav", [_resourceBundle resourcePath], AudioName]];
    _audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:AudioUrl error:nil];
    [self AudioPlayerStart];
}

- (void)AudioPlayerStart {
    _audioPlayer.volume = 1;
    _audioPlayer.delegate = self;
    [_audioPlayer prepareToPlay];
    [_audioPlayer play];
}

#pragma mark - 播放完成回掉接口
/*播放完成回掉接口*/
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    _audioPlayer = nil;
    
    if (_CurrentPlayStatus == VoiceTypeWaiting) {       //播放等待提示音结束
        VcyberLog(@"等待提示音播放完毕 %d", _IsCancelTask);
        [self PlayVoice:VoiceTypeWaiting PlayData:nil];
    } else if (_CurrentPlayStatus == VoiceTypeTTSPlay) {    //播放TTS结束
        VcyberLog(@"TTS播放完毕");
        
#if LogCtrol
        [self.cacheRecordData setData:[NSData data]];
#endif
        [_httpRequest resetAudioIndex];
        
//        [self beginRecordAndCallBack]; //开始录音并回调
        [_recordTask SetAudioValid];
        
    } else if (_CurrentPlayStatus == VoiceTypeErrorPlay) {  //播放错误提示音结束
        VcyberLog(@"错误提示音播放完毕");
        [self CancleSession];
    } else if(_CurrentPlayStatus == VoiceTypeTTSOver){  //最后一个TTS播放结束
        VcyberLog(@"最后一个TTS播放完毕");
        [self CancleSession];
    }
}

#pragma mark - 录音开始&回调

- (void)beginRecordAndCallBack {
    if (0 == [self beginRecord]) {
        [self sendCallBackBeginRecord]; //录音开始回调
    } else {
        [self CancleSession];
        VcyberLog(@"CYV_BEGINRECORD_ERROR");
        [self sendCallBackBeginError:CYV_BEGINRECORD_ERROR]; //录音启动失败发送初始化失败回调
    }
}

- (OSStatus)beginRecord {
    __darwin_time_t ret2 = [self getTimeOfNow];
    OSStatus statusCode = [_recordTask AudioSessionStart];
    __darwin_time_t ret3 = [self getTimeOfNow];
    DPrint("启动时间 %ld\n", ret3 - ret2);
    return statusCode;
}

- (__darwin_time_t)getTimeOfNow {
    struct timeval timeNow;
    gettimeofday(&timeNow, NULL);
    __darwin_time_t ret = timeNow.tv_sec * 1000000 + timeNow.tv_usec;
    return ret;
}

- (void)sendCallBackBeginRecord {
    if (self.delegate && [self.delegate respondsToSelector:@selector(CallBackBeginRecord)]) {
        [self.delegate CallBackBeginRecord];
    }
}

#pragma mark - 发送音频

/*强制发送接口*/
- (void)ForceSendToServer {
    if (_recordTask) {
        [_recordTask StopAudio];
    }
}

- (void)SendVoiceToServer:(NSData *)AudioData status:(NSString *)status isSpeaking:(BOOL)isSpeak {
    VcyberLog(@"状态: %@", isSpeak==YES?@"说话中.....":@"未说话!");
    if (_IsCancelTask) {
        return;
    }
    if ([status isEqual:@"AudioBefore"]) {
#if LogCtrol
        [self.cacheRecordData appendData:AudioData];
#endif
        if (isSpeak) {
            [_httpRequest httpPutAudio:(char*)[AudioData bytes] AudioLength:(int)AudioData.length AudioStatus:VCYBER_AUDIO_FIRST];
        }
        
    } else {
#if LogCtrol
        NSData * RecondData = [vcyberEncryptUtil AddHeader:self.cacheRecordData Channels:1 LongSampleRate:16000 ByteRate:16000];
        [WHSaveAudioUtil WHWriteRecordDataToFile:RecondData];
#endif
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(CallBackEndRecord)]) {
            [self.delegate CallBackEndRecord];
        }
        if (_IsPlayTTS) {
            [self PlayVoice:VoiceTypeWaiting PlayData:nil];
        }
        if (AudioData != nil) {
            [_httpRequest httpPutAudio:(char*)[AudioData bytes] AudioLength:(int)AudioData.length AudioStatus:VCYBER_AUDIO_LAST];
        } else {
            char *voicechar= NULL;
            [_httpRequest httpPutAudio:voicechar AudioLength:2 AudioStatus:VCYBER_AUDIO_LAST];
        }
    }
}

#pragma mark - 发送音频回调

- (void)httpPutAudioResult:(NSInteger)flag result:(VDResultData *)resultData {
    
    if (flag != 0) {
        if (flag != CYV_CANCEL) {
            [_recordTask SetCancle];
            [self sendCallBackErrorDelegate:flag];
            [self PlayVoice:VoiceTypeErrorPlay PlayData:nil];
        }
        
        return;
    }else{
        if ([resultData.error integerValue] !=0) {
            [self sendCallBackErrorDelegate:[resultData.error  integerValue]];
            [self PlayVoice:VoiceTypeErrorPlay PlayData:nil];
            return;
        }
    }
    NSData * voicedata = [vcyberEncryptUtil AddHeader:resultData.audio Channels:1 LongSampleRate:8000 ByteRate:16000];
    if ([self CheckFinish:resultData]){
        if (self.delegate && [self.delegate respondsToSelector:@selector(CallBackResult:)]) {
            [self.delegate CallBackResult:resultData];
        }
        if (_IsPlayTTS) {
            [self PlayVoice:VoiceTypeTTSOver PlayData:voicedata]; //会话结束
        }else{
            [self CancleSession];
        }
        
    } else {
        if (self.delegate && [self.delegate respondsToSelector:@selector(HalfCallBack:)]) {
            [self.delegate HalfCallBack:resultData];
        }
        
        if (_IsPlayTTS) {
            [self PlayVoice:VoiceTypeTTSPlay PlayData:voicedata]; //中途会话
        } else {
            [_httpRequest resetAudioIndex];
            
//            [self beginRecordAndCallBack]; //开始录音并回调
            [_recordTask SetAudioValid];
        }
    }
}

#pragma mark - SessionEnd 回调

- (void)httpSessionEndResult:(NSInteger)flag {
    if (_httpRequest!=nil) {
        _httpRequest.delegate = nil;
        _httpRequest = nil;
        VcyberLog(@"_httpRequest release");
    }
}

#pragma mark - 出错回调

- (void)sendCallBackErrorDelegate:(NSInteger)errorCode {
    if (self.delegate && [self.delegate respondsToSelector:@selector(CallBackError:)]) {
        [self.delegate CallBackError:errorCode];
    }
}

#pragma mark - 显示音量

/*显示音量*/
- (void)ShowVoluemState:(int)num AudioValid:(BOOL)valid {
    
    NSString *vcyberImageName = [NSString stringWithFormat:@"%@_%d",valid==YES?@"Record":@"Play", num];
    
    if(_VDSessionView){
        [_VDSessionView setVcyberImageView:vcyberImageName];
    }
}

- (void)SetVolumeState:(int)voiceNum AudioValid:(BOOL)valid {
    if(_VDSessionView){
        dispatch_async(dispatch_get_main_queue(), ^{
            [self ShowVoluemState:voiceNum AudioValid:valid];
        });
    }
    if (self.delegate && [self.delegate respondsToSelector:@selector(CallBackVolume:)]) {
        [self.delegate CallBackVolume:voiceNum];
    }
}

#pragma mark - 判断流程释放结束

/*判断流程释放结束*/
- (BOOL)CheckFinish:(VDResultData *)vdResultData {
    if (vdResultData != nil) {
        if ([vdResultData.error intValue] == 0) {
            if ([vdResultData.type rangeOfString:@"en"].location == NSNotFound) {
                return YES;
            }
            else{
                return NO;
            }
        }else{
            return YES;
        }

    }else{
        return YES;
    }
    
}


#pragma mark - Handle

- (NSMutableData *)cacheRecordData
{
    if (!_cacheRecordData) {
        _cacheRecordData = [[NSMutableData alloc] initWithCapacity:0];
    }
    return _cacheRecordData;
}

@end
