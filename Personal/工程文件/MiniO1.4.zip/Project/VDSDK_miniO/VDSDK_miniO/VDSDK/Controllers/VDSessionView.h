//
//  VDSessionView.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol VDSessionViewDelegate <NSObject>

- (void)CancleSession;

@end

@interface VDSessionView : UIView

@property (nonatomic, weak) id <VDSessionViewDelegate>Sdelegate;

- (void)setVcyberImageView:(NSString *)vcyberImageName;

@end
