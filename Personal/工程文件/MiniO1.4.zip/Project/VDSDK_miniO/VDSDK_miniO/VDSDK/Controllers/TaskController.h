//
//  TaskController.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "VDResultData.h"

@class VDSessionParamsManager;

@protocol TaskDelegate;

@interface TaskController : NSObject

@property (weak, nonatomic) id <TaskDelegate>delegate;

- (instancetype)initWithSessionParam:(VDSessionParamsManager *)SessionParams; //初始化

- (void)InitStartThread; //开启SDK会话

- (void)CancleSession; //取消SDK会话 并释放内存

- (void)ForceSendToServer; //强制结束录音并发送音频

@end


@protocol TaskDelegate<NSObject>
@optional

- (void)HalfCallBack:(VDResultData *)result; //中途会话返回回调

- (void)CallBackBeginError:(NSInteger)result; // 初始化失败
- (void)CallBackError:(NSInteger)result; //返回错误信息 结果参考文档

- (void)CallBackBeginRecord; //返回开始录音标志
- (void)CallBackEndRecord; //返回结束录音标志

- (void)CallBackVolume:(NSInteger)currentvolume; //返回音量标志
- (void)CallBackResult:(VDResultData *)result; //返回结果 结果类型参考文档

- (void)CallBackFinishAll; //行为结束,可以释放当前对象资源

@end

