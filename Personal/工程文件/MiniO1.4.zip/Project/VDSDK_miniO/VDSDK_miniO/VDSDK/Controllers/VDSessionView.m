//
//  VDSessionView.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "VDSessionView.h"
#import "VDCommon.h"

@interface VDSessionView ()

@property (nonatomic, strong) NSBundle *resourceBundle; //资源文件
@property (nonatomic, strong) UIButton *backButton;
@property (nonatomic, strong) UIImageView *imageView;

@end

@implementation VDSessionView

- (void)setVcyberImageView:(NSString *)vcyberImageName {
    [self bringSubviewToFront:_imageView];
    UIImage *vcyberImage = [UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/vcyber_%@.png",[_resourceBundle resourcePath], vcyberImageName]] ;
    if (vcyberImage) {
        [_imageView setImage:vcyberImage];
    }
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setResource];
        
        [self setupBackBtn];
        [self setupImageView];
        
    }
    return self;
}

- (void)setResource {
    NSString * bundlePath = [[NSBundle mainBundle] pathForResource:@"Resource" ofType:@"bundle"];
    _resourceBundle = [NSBundle bundleWithPath:bundlePath];
//    VcyberLog(@"ResourceBundle:%@", _resourceBundle);
}

- (void)setupBackBtn {
    
    _backButton = [UIButton new];
    [self addSubview:_backButton];
    [_backButton addTarget:self action:@selector(backButtonClicked) forControlEvents:UIControlEventTouchDown];
}


- (void)backButtonClicked {
    //    VcyberLog(@"backButtonClicked");
    if (self.Sdelegate && [self.Sdelegate respondsToSelector:@selector(CancleSession)])
    {
        [self.Sdelegate CancleSession];
    }
}

- (void)setupImageView {
    UIImage * image = [UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/vcyber_Record_%@",[_resourceBundle resourcePath],@"0.png"]];
    if (image) {
        _imageView = [[UIImageView alloc] initWithImage:image];
        _imageView.layer.shadowOffset = CGSizeMake(5, 3);
        _imageView.layer.shadowOpacity = 0.6;
        _imageView.layer.shadowColor = [UIColor blackColor].CGColor;
        _imageView.userInteractionEnabled = YES;
        
        [self addSubview:_imageView];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    //    self.backgroundColor = [UIColor redColor];
    
    UIApplication *application =  [UIApplication sharedApplication];
    CGFloat screenWith, screenHeight;
    if(application.statusBarOrientation == UIDeviceOrientationPortrait) {
        screenWith = MIN(self.frame.size.width, self.frame.size.height);
        screenHeight = MAX(self.frame.size.width, self.frame.size.height);
    } else {
        screenWith = MAX(self.frame.size.width, self.frame.size.height);
        screenHeight = MIN(self.frame.size.width, self.frame.size.height);
        
    }
    
    self.frame = CGRectMake(0, 0, screenWith, screenHeight);
    self.backButton.frame = self.frame;
    
    
    NSInteger picwith = screenWith *0.95;
    NSInteger picheight = screenHeight * 0.95;
    
    CGRect imageFrame;
    if(application.statusBarOrientation == UIDeviceOrientationPortrait) {
        imageFrame = CGRectMake(0, 0, picwith, picwith*200/300);
        
    } else {
        imageFrame = CGRectMake(0, 0, picheight, picheight*200/300);
    }
    
    self.imageView.frame = imageFrame;
    self.imageView.center = self.center;
}

@end

