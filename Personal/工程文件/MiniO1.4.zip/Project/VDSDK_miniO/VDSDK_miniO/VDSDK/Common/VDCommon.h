//
//  VDCommon.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/16.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#ifndef VDCommon_h
#define VDCommon_h

#import <Foundation/Foundation.h>

#pragma mark - macor
#pragma mark -

#define LogCtrol 0

#if LogCtrol
#   define VcyberLog(fmt, ...) \
\
NSLog(@"%s [Line %d] " fmt, __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__); \

#   define DPrint(format, ...) printf(format, ##__VA_ARGS__)

#else
#   define VcyberLog(...);
#   define DPrint(format, ...)
#endif


#endif