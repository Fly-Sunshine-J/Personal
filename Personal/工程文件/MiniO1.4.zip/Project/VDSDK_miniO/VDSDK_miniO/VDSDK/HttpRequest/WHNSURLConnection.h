//
//  WHNSURLConnection.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/14.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WHNSURLConnection;

@protocol WHNSURLConnectionDelegate <NSObject>

- (void)WHconnection:(WHNSURLConnection *)connection didFailWithError:(NSError *)error;

@end

@protocol WHNSURLConnectionDataDelegate <NSObject>

- (void)WHconnection:(WHNSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response;
- (void)WHconnection:(WHNSURLConnection *)connection didReceiveData:(NSData *)data;
- (void)WHconnectionDidFinishLoading:(WHNSURLConnection *)connection;

@end



@interface WHNSURLConnection : NSURLConnection

@property (nonatomic, strong) NSString *ConnectionTagName;
@property (nonatomic, strong) NSMutableData *receiveData;


@end
