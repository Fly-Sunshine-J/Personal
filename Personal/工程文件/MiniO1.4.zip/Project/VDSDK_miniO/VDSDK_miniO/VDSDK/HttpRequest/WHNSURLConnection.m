//
//  WHNSURLConnection.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/14.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "WHNSURLConnection.h"

@interface WHNSURLConnection ()<NSURLConnectionDataDelegate, NSURLConnectionDelegate>

@property (nonatomic, weak) id <WHNSURLConnectionDataDelegate>WHNSURLConnectionDataDelegate;
@property (nonatomic, weak) id <WHNSURLConnectionDelegate>WHNSURLConnectionDelegate;

@end

@implementation WHNSURLConnection

- (instancetype)initWithRequest:(NSURLRequest *)request delegate:(id)delegate startImmediately:(BOOL)startImmediately {
    if (self = [super initWithRequest:request delegate:self startImmediately:startImmediately]) {
        _WHNSURLConnectionDataDelegate = delegate;
        _WHNSURLConnectionDelegate = delegate;
    }
    return self;
}

#pragma mark - WHNSURLConnectionDelegate

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    if (self.WHNSURLConnectionDelegate && [self.WHNSURLConnectionDelegate respondsToSelector:@selector(WHconnection:didFailWithError:)])
    {
        [self.WHNSURLConnectionDelegate WHconnection:self didFailWithError:error];
    }
}

#pragma mark - WHNSURLConnectionDataDelegate

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    if (self.WHNSURLConnectionDataDelegate && [self.WHNSURLConnectionDataDelegate respondsToSelector:@selector(WHconnection:didReceiveResponse:)])
    {
        [self.WHNSURLConnectionDataDelegate WHconnection:self didReceiveResponse:response];
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    if (self.WHNSURLConnectionDataDelegate && [self.WHNSURLConnectionDataDelegate respondsToSelector:@selector(WHconnection:didReceiveData:)]) {
        [self.WHNSURLConnectionDataDelegate WHconnection:self didReceiveData:data];
    }
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    if (self.WHNSURLConnectionDataDelegate && [self.WHNSURLConnectionDataDelegate respondsToSelector:@selector(WHconnectionDidFinishLoading:)]) {
        [self.WHNSURLConnectionDataDelegate WHconnectionDidFinishLoading:self];
    }
}

@end
