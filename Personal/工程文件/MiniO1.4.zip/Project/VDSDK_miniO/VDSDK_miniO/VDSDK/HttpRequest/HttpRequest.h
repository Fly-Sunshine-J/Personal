//
//  HttpRequest.h
//  NewVDSDKDemoTest
//
//  Created by dengweihao on 15/12/25.
//  Copyright © 2015年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VDResultData.h"

@class VDSessionParamsManager;

@protocol HttpRequestDelegate <NSObject>

- (void)httpSessionBeginResult:(NSInteger)flag result:(VDResultData *)resultData;
- (void)httpPutAudioResult:(NSInteger)flag result:(VDResultData *)resultData;
- (void)httpSessionEndResult:(NSInteger)flag;

@end

@interface HttpRequest : NSObject

@property (weak, nonatomic) id <HttpRequestDelegate>delegate;

- (instancetype)initWithSessionParams:(VDSessionParamsManager *)mapParams;
- (void)resetAudioIndex;
- (void)httpSessionBegin;
- (void)httpPutAudio:(char *)audiobytes AudioLength:(int)audioLength AudioStatus:(int)audioStatus;
- (void)httpSessionEnd;
- (void)httpSetCancel;

@end
