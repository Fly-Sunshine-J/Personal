#pragma once




//启动会话
#define SessionBeginSting   @"Method=QASRSessionBegin&Configs=AppID=%@;Version=%@;UserID=%@;compress_model=%ld;audio_format=%ld;sample_bits=%ld;time_out=%ld;noise_reduc=%ld;Quality=%ld;TTS=%@;"

//发送音频
#define PutAudioString      @"Method=QASRPutAudio&AudioIndex=%ld&LastAudio=%@&Audio=%@"


//结束会话
#define SessionEndString    @"Method=QASRSessionEnd"