//
//  HttpRequest.m
//  NewVDSDKDemoTest
//
//  Created by dengweihao on 15/12/25.
//  Copyright © 2015年 dengweihao. All rights reserved.
//

#import "HttpRequest.h"
#import "VDGlouble.h"
#import "vcyberEncryptUtil.h"
#import "VDCommon.h"
#import "AudioUtil.h"
#import "VDSessionParamsManager.h"
#import "WHNSURLConnection.h"
#import "URLEncodeUtil.h"
#import "URLRequestString.h"
//#import "VcyberSpeex.h"
#import "WHSaveAudioUtil.h"

@interface HttpRequest ()<WHNSURLConnectionDelegate, WHNSURLConnectionDataDelegate>

@property (nonatomic, strong) NSString *serverUrl;
@property (nonatomic, strong) NSString *appID;
@property (nonatomic, strong) NSString *key;
@property (nonatomic, strong) NSString *userID;
@property (nonatomic, assign) NSInteger nCompressMode;
@property (nonatomic, assign) NSInteger nAudioFormat;
@property (nonatomic, assign) NSInteger nSampleBits;
@property (nonatomic, assign) NSInteger nTimeOut;
@property (nonatomic, assign) NSInteger nNoiseReduce;
@property (nonatomic, assign) NSInteger nQuality;
@property (nonatomic, strong) NSString *nTTS;

@property (nonatomic, assign) NSInteger RecordSamplingRate;

@property (nonatomic, strong) NSString *VERSION;
@property (nonatomic, strong) NSString *nSessionID;

@property (nonatomic, assign) NSInteger nAudioIndex;

@property (nonatomic, assign) BOOL IsCancel;
@property (nonatomic, assign) BOOL IsSessionBeginSucess;

@property (nonatomic, strong) WHNSURLConnection *sessionBeginConnection;

//@property (nonatomic, assign) CVcyberSpeex *vs;

/*
 * 设置请求cookie，发送httpSessionBegin获取cookie,
 * 发送httpPutAudio使用该cookie.
 */
@property (nonatomic, strong) NSString *setCookie;

@end

@implementation HttpRequest

#pragma mark - 初始化参数

/**
 * 初始化参数
 */
- (instancetype)init {
    if (self = [super init]) {
        [self reset];
        _VERSION = @"v1.0 Beta";
    }
    return self;
}

- (void)reset {
    _nAudioIndex = 0;
    _nSessionID = @"";
    _IsCancel = NO;
    _IsSessionBeginSucess = NO;
    _setCookie = @"";
}

- (instancetype)initWithSessionParams:(VDSessionParamsManager *)mapParams {
    if (self = [self init]) {
        if (mapParams.serverUrl != nil) {  //语音识别引擎服务器地址
            _serverUrl = mapParams.serverUrl;
        }
        if (mapParams.appId != nil) { //语音识别引擎appkey
            NSString *sTotal = mapParams.appId;
            if ([sTotal length] == 45) {
                _appID = [sTotal substringToIndex:8] ; //前8位
                _key  = [sTotal  substringFromIndex:9]; //后面37位
            }
        }
        if (mapParams.userId != nil) { //用户名,默认guest
            _userID = mapParams.userId;
        }
        _nCompressMode = mapParams.compressModel; //压缩模型,默认0
        _nAudioFormat = mapParams.audioFormat; //录音采样率 1:8000 ; 2:16000
        
        switch (_nAudioFormat) {
            case 1:_RecordSamplingRate = 8000;break;
            case 2:_RecordSamplingRate = 16000;break;
            default:
                _RecordSamplingRate = 8000;
                break;
        }
        _nSampleBits = mapParams.sampleBits;
        _nTimeOut = mapParams.timeOut; //服务器连接超时时间,默认30s
        _nNoiseReduce = mapParams.noiseReduce;
        _nQuality = mapParams.quality;  //音频质量,默认10
        _nTTS = mapParams.TTS;
    }
    return self;
}

#pragma mark - 取消会话

- (void)httpSetCancel
{
    _IsCancel = YES;
    [self.sessionBeginConnection cancel];
    VcyberLog(@"取消会话");
}

#pragma mark - 重置AudioIndex

- (void)resetAudioIndex
{
    _nAudioIndex = 0;
}

#pragma mark - 会话开始

- (void)httpSessionBegin {
    if (_serverUrl == nil) {
        [self sendBeginDelegate:CYV_ERROR_SERVEURL result:nil];
        return;
    }
    if (_appID == nil || _key == nil) {
        [self sendBeginDelegate:CYV_APPKEY_INVALID result:nil];
        return;
    }
    
    NSString* pUser = [vcyberEncryptUtil EncryptPefect:_userID key:_key]; // 加密
    
    if ([[NSThread currentThread] isCancelled] == NO && !_IsCancel) {
        
        NSString *SessionBeginBody = [[NSString alloc] initWithFormat:
                             SessionBeginSting,
                             _appID,
                             _VERSION,
                             pUser,
                             (long)_nCompressMode,
                             (long)_nAudioFormat,
                             (long)_nSampleBits,
                             (long)_nTimeOut,
                             (long)_nNoiseReduce,
                             (long)_nQuality,
                             _nTTS];
        
        NSURLRequest *request = [self requestParam:SessionBeginBody header:nil];
        
        self.sessionBeginConnection = [[WHNSURLConnection alloc] initWithRequest:request delegate:self startImmediately:NO];
        self.sessionBeginConnection.ConnectionTagName = @"SDKSessionBegin";
        [self.sessionBeginConnection scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
        [self.sessionBeginConnection start];
//        _vs = new CVcyberSpeex();
        
    }
}

#pragma mark - 创建URL请求

- (NSURLRequest *)requestParam:(NSString *)bodyStr header:(NSDictionary *)headerDic {
    NSURL *url = [NSURL URLWithString:_serverUrl];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setTimeoutInterval:_nTimeOut];
    
    if (headerDic) [request setAllHTTPHeaderFields:headerDic];
    
    NSData *httpBody = [NSData dataWithBytes:bodyStr.UTF8String length:bodyStr.length];
    
    [request setHTTPBody:httpBody];
    return request;
}

#pragma mark - WHNSURLConnectionDelegate

- (void)WHconnection:(WHNSURLConnection *)connection didFailWithError:(NSError *)error {
    VcyberLog(@"%@ Fail. Error = %@", connection.ConnectionTagName, error);
    [self sendBeginDelegate:CYV_ERR_NET_ACCESS_FAILED result:nil];
}

#pragma mark - WHNSURLConnectionDataDelegate

- (void)WHconnection:(WHNSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    NSHTTPURLResponse *res = (NSHTTPURLResponse *)response;
    if (res.statusCode == 200) {
        connection.receiveData = [NSMutableData data];
        
        // SessionBegin 获取SessionID
        if ([connection.ConnectionTagName isEqualToString:@"SDKSessionBegin"]) {
            NSString *sTemp = [res.allHeaderFields objectForKey:@"Set-Cookie"];
            if([sTemp rangeOfString:@"ASP.NET_SessionId="].location != NSNotFound ){
                NSInteger nBegin = [@"ASP.NET_SessionId=" length];
                if ([_setCookie isEqualToString:@""]) {
                    _nSessionID = [sTemp substringWithRange:NSMakeRange(nBegin,24)];
                    _setCookie = [NSString stringWithFormat:@"ASP.NET_SessionId=%@", _nSessionID];
                }
                VcyberLog(@"allHeaderFields %@", res.allHeaderFields);
            }
        }
    } else {
        NSString *error = [NSString stringWithFormat:@"http error %ld",(long)res.statusCode];
        VcyberLog(@"%@ - Fail. ErrorCode = %@", connection.ConnectionTagName, error);
        [self sendBeginDelegate:CYV_ERR_NET_ACCESS_FAILED result:nil];
    }
}

- (void)WHconnection:(WHNSURLConnection *)connection didReceiveData:(NSData *)data {
    [connection.receiveData appendData:data];
//    VcyberLog(@"接收数据-----%@", connection.ConnectionTagName);
}

- (void)WHconnectionDidFinishLoading:(WHNSURLConnection *)connection {
    
    NSMutableData *data = (NSMutableData *)[connection.receiveData copy];
    VDResultData *resultput = [[VDResultData alloc] init];
    // 解析数据
    [self gridResult:(NSMutableData*)data Result:resultput];
    
    if ([connection.ConnectionTagName isEqualToString:@"SDKSessionBegin"]) {
        VcyberLog(@"QASRSessionBegin Success.");
        _IsSessionBeginSucess = YES;
        
        [self sendBeginDelegate:[resultput.error intValue] result:resultput];
    }
    
    if ([connection.ConnectionTagName isEqualToString:@"SDKPutAudioBegin"]) {
        VcyberLog(@"QASRPutAudio - %@ - Success.", connection.ConnectionTagName);
        
        if ([resultput.error integerValue] != 0) {
            [self sendPutAudioDelegate:[resultput.error integerValue] result:resultput];
        }
    }
    
    if ([connection.ConnectionTagName isEqualToString:@"SDKPutAudioLast"]) {
        VcyberLog(@"QASRPutAudio - %@ - Success.", connection.ConnectionTagName);
        
        [self sendPutAudioDelegate:[resultput.error integerValue] result:resultput];
    }
    
    if ([connection.ConnectionTagName isEqualToString:@"SDKSessionEnd"]) {
        [self sendSessionEndDelegate:CYV_SUCCESS];
        VcyberLog(@"SessionEnd Success step3");
    }
}


#pragma mark - 会话开始代理
/**
 *  开始结果代理处理
 */
- (void)sendBeginDelegate:(NSInteger)flag result:(VDResultData *)result
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(httpSessionBeginResult:result:)])
    {
        [self.delegate httpSessionBeginResult:flag result:result];
    }
}


#pragma mark - 发送语音
/**
 * 向服务器发送音频接口
 */
- (void)httpPutAudio:(char *)audiobytes AudioLength:(int)audioLength AudioStatus:(int)audioStatus
{
//    VcyberLog(@"audioLength %d", audioLength);
    if ([@"" isEqualToString:_setCookie])
    {   // Cookie不存在的场合
        [self sendPutAudioDelegate:CYV_ERR_REQUEST_INVALID_STATUS result:nil];
        return;
    }
    
    NSString *sLastAudio = @"false";
    NSString * URLEncodeAudioBase64String;
    if (_nCompressMode == 1 || _nCompressMode ==3)
    {
        if (audioStatus != VCYBER_AUDIO_LAST)
        {
            sLastAudio = @"false";
            
            NSData *AudioData = [NSData dataWithBytes:audiobytes length:audioLength];
            NSData *encodedAudioData = [NSData data];
            //压缩音频
            int encodeCode = [AudioUtil tsilkEncodeAudio:AudioData encodedData:&encodedAudioData samplingRate:_RecordSamplingRate level:_nQuality];
            if (encodeCode != 0) {
                [self sendPutAudioDelegate:CYV_SILK_ENCODE_ERROR result:nil];
            }
            NSString *AudioBase64String = [encodedAudioData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
            
            [URLEncodeUtil URLEncode:AudioBase64String OutStr:&URLEncodeAudioBase64String];
            
        } else {
            sLastAudio = @"true";
            URLEncodeAudioBase64String = @"";
        }
        
        //发送音频
        NSString *PutAudioBody = [[NSString alloc] initWithFormat:PutAudioString,
                                  (long)_nAudioIndex,
                                  sLastAudio,
                                  URLEncodeAudioBase64String];
        
        NSDictionary *headerDic = @{@"Cookie":_setCookie};
        NSURLRequest *request = [self requestParam:PutAudioBody header:headerDic];
        
        if (_IsCancel)
        {
            [self sendPutAudioDelegate:CYV_CANCEL result:nil];
            return;
        }
        
        WHNSURLConnection *connection = [[WHNSURLConnection alloc] initWithRequest:request delegate:self startImmediately:NO];
        if (audioStatus == VCYBER_AUDIO_FIRST) {
            connection.ConnectionTagName = @"SDKPutAudioBegin";
        } else {
            connection.ConnectionTagName = @"SDKPutAudioLast";
        }
        
        [connection scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
        [connection start];
        
        _nAudioIndex++;
    } else {
        [self sendPutAudioDelegate:CYV_ERR_FAIL_ENCODE result:nil];
    }
}


#pragma mark - 语音发送结果代理
/**
 *  语音发送结果代理处理
 */
- (void)sendPutAudioDelegate:(NSInteger)flag result:(VDResultData *)result
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(httpPutAudioResult:result:)])
    {
        [self.delegate httpPutAudioResult:flag result:result];
    }
}


#pragma mark - 发送会话结束请求
- (void)httpSessionEnd
{
    if (_IsSessionBeginSucess) {
        VcyberLog(@"sessionEnd step2");
        NSString *SessionEndBody = [[NSString alloc] initWithFormat:SessionEndString];
        
        NSDictionary *headerDic = @{@"Cookie":_setCookie};
        NSURLRequest *SessionEndRequest = [self requestParam:SessionEndBody header:headerDic];
        WHNSURLConnection *connection = [[WHNSURLConnection alloc] initWithRequest:SessionEndRequest delegate:self startImmediately:NO];
        connection.ConnectionTagName = @"SDKSessionEnd";
        [connection scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
        [connection start];
    }
}

#pragma mark - 会话结束代理
/**
 *  语音发送结果代理处理
 */
- (void)sendSessionEndDelegate:(NSInteger)flag
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(httpSessionEndResult:)])
    {
        [self.delegate httpSessionEndResult:flag];
    }
}

#pragma mark 处理返回数据的结果
/**
 * 处理结果
 */
- (int)gridResult:(NSMutableData *)data Result:(VDResultData *)rd
{
    NSMutableString* sTemp = [[NSMutableString alloc] init];
    NSString* sTotal = [[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding];
    for(int i = 0; i<[sTotal length]; ++i){
        if([sTotal characterAtIndex:i]=='\n'){
            if([sTemp rangeOfString:@"{"].location !=NSNotFound && [sTemp rangeOfString:@"}"].location !=NSNotFound){
                break;
            }
            if([sTemp rangeOfString:@"Set-Cookie: ASP.NET_SessionId="].location !=NSNotFound ){
                NSInteger nBegin = [@"Set-Cookie: ASP.NET_SessionId=" length];
                if ([_nSessionID isEqualToString:@""]) {
                    _nSessionID = [[sTemp substringWithRange:NSMakeRange(nBegin,24)] copy];
                }
            }
            [sTemp setString:@""];
        }
        else if ([sTotal characterAtIndex:i]!='\r'){
            NSRange range = NSMakeRange(i, 1);
            NSString * subString = [[NSString alloc] initWithString: [sTotal substringWithRange:range]];
            [sTemp appendString:subString];
        }
    }
    NSString * baseencode = [sTemp stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    if (baseencode == nil) {
        return CYV_ERR_RECEIVEDATA;
    }
    NSString *cleanUrlString = [[NSString alloc] initWithString: [sTemp stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
//    VcyberLog(@"cleanUrlString %@", cleanUrlString);
    
    if ([cleanUrlString rangeOfString:@";"].location != NSNotFound) {
        NSArray * parentArr = [[NSArray alloc] initWithArray:[cleanUrlString componentsSeparatedByString:@";"]];
        for (NSString* str in parentArr) {
            if ([str rangeOfString:@"="].location != NSNotFound) {
                NSArray * arr = [[NSArray alloc] initWithArray:[str componentsSeparatedByString:@"="]];
                NSString * objkey = [arr objectAtIndex:0];
                if (![objkey  isEqual: @""] && ![objkey isEqual:nil]) {
                    if ([objkey isEqualToString:@"Error"]) {
                        rd.error = [[NSNumber alloc] initWithInt:[[arr objectAtIndex:1] intValue]];
                    }
                    else if ([objkey isEqualToString:@"Status"]) {
                        rd.status = [[NSNumber alloc] initWithInt:[[arr objectAtIndex:1] intValue]];
                    }
                    else if ([objkey isEqualToString:@"Text"]) {
                        NSInteger lentts = [[arr objectAtIndex:1] length];
                        rd.textLength = [[NSNumber alloc] initWithInteger:lentts];
                        rd.text = [arr objectAtIndex:1];
                        
                        VcyberLog(@"Setm_TTSTotal : %@", [arr objectAtIndex:1]);
                    }
                    else if ([objkey isEqualToString:@"AudioLenth"]) {
                        rd.audioLenth = [[NSNumber alloc] initWithInt:[[arr objectAtIndex:1] intValue]];
                    }
                    else if ([objkey isEqualToString:@"Audio"]) {
                        
                        NSMutableString *tempBas4Str = [[NSMutableString alloc] init];
                        int i ;
                        for (i = 0; i<[arr count]; ++i) {
                            if (i>0) {
                                if (i==1) {
                                    [tempBas4Str appendString:[arr objectAtIndex:i]];
                                    VcyberLog(@"");
                                }else{
                                    [tempBas4Str appendString:@"="];
                                    VcyberLog(@"********");
                                }
                            }
                        }
                        rd.base64Audio = tempBas4Str;
                        
                        
                    }
                    else if ([objkey isEqualToString:@"Type"]) {
                        rd.type = [arr objectAtIndex:1];
                    }
                    
                }
            }
        }
    }
    
    if (rd.base64Audio != nil) {
        
        NSData* encodedAudioData = [[NSData alloc] initWithBase64EncodedString:rd.base64Audio options:NSDataBase64DecodingIgnoreUnknownCharacters];
        
//        [WHSaveAudioUtil WHWriteDataToFile:encodedAudioData FileType:@"base64"];
#if 1
        
        if ([encodedAudioData length] != 0) {
            
            NSData *decodedData = [NSData data];
            int decodedCode = [AudioUtil tsilkDecodeAudio:encodedAudioData decodedData:&decodedData samplingRate:_RecordSamplingRate];
            if (decodedCode != 0) {
                return CYV_SILK_DECODE_ERROR;
            }
            
            rd.audio = decodedData;
            
        }else{
            VcyberLog(@"ERR DECODE %@",@"...............");
        }
#endif
        
#if 0
        NSData *nd = [encodedAudioData copy];
        char* DecodeData = NULL;
        int nDecodeWaveLen = 0;
        if ([nd length] != 0) {
            int err = 0;
            err = _vs->AllocDecode((int)1, (int)_nQuality);
            if (err != 0) {
                return err;
            }
            err = _vs->SilkDecode((char*)[nd bytes], (int)[nd length], &nDecodeWaveLen, &DecodeData);
            if (err != 0) {
                return err;
            }
            _vs->DeleteDecode();
            
            NSData * ndtmp = [[NSData alloc] initWithBytes:DecodeData length:nDecodeWaveLen];
            
            if (DecodeData != NULL) {
                free(DecodeData);
            }
            [rd Setm_Audio:ndtmp];
        }
#endif

    }else{
        VcyberLog(@"Encoded Base64 AudioData Is NULL");
    }
    return  CYV_SUCCESS;
}

@end
