//
//  VcyberTaskUtil.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/17.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "VcyberTaskUtil.h"

@implementation VcyberTaskUtil

/**
 *  请求类型转换
 */
+ (NSString *)changeType:(NSString *)type
{
    if ([@"poiplace" isEqualToString:type])
    {
        return @"POI";
    } else if ([@"command" isEqualToString:type]) {
        return @"Command";
    } else if ([@"end" isEqualToString:type]) {
        return @"end";
    } else {
        return @"";
    }
}

/**
 *  检测对象是否为空
 */
+ (id)checkIsNull:(id)str
{
    if (!str || [NSNull null] == str)
    {
        return @"";
    }
    return str;
}

/**
 *  POI类型转换
 */
+ (NSString *)changePOIType:(NSString *)type
{
    if ([@"poi" isEqualToString:type])
    {
        return @"Search";
    } else if ([@"poinear" isEqualToString:type]) {
        return @"AroundSearch";
    } else {
        return @"";
    }
}

@end
