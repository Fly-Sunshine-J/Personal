//
//  VDFeedBackHelper.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/17.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "VDFeedBackHelper.h"
#import "VDSessionParamsManager.h"
#import "VcyberTaskUtil.h"
#import "TaskController.h"
#import <AVFoundation/AVFoundation.h>

#define O_T_APP_ID @"cyw00016-D618AE9F-ED17-CB17-D6D5-0A5CFA4F15AB" //小O吐槽项目Key

@interface VDFeedBackHelper ()<TaskDelegate>

@property (nonatomic, weak) id <VDFeedbackDelegate>FeedbackDelegate;
@property (nonatomic, strong) TaskController *FeedBackTaskV;

@end

@implementation VDFeedBackHelper

- (instancetype)init {
    if (self = [super init]) {
        [[AVAudioSession sharedInstance] setActive:YES error:nil];
        [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:(AVAudioSessionCategoryOptionMixWithOthers|AVAudioSessionCategoryOptionDefaultToSpeaker) error:nil];
    }
    return self;
}

- (void)beginFeedbackWithDelegate:(id<VDFeedbackDelegate>)delegate
                        longitude:(double)longitude
                         latitude:(double)latitude
                       isShowView:(bool)isShowView
                           params:(VDSessionParamsManager *)params
{
    VDSessionParamsManager *hash;
    if (params && nil != params && (id)[NSNull null] != params)
    {
        hash = params;
    } else {
        hash = [[VDSessionParamsManager alloc] init];
    }
    
    NSString *userId = [NSString stringWithFormat:@"program:ajx_tc&user:%@&version:ios20160427&poi:%lf,%lf", hash.telNumber,longitude,latitude];
    
    hash.serverUrl = @"http://vdialog.vcyber.com:10007";
    hash.userId = userId;
    hash.appId = O_T_APP_ID;
    hash.isShowView = isShowView;
    if (hash.audioFormat!=1&&hash.audioFormat!=2) {
        hash.audioFormat = 2;
    }
    
    _FeedBackTaskV = [[TaskController alloc] initWithSessionParam:hash];
    _FeedBackTaskV.delegate = self;
    
    self.FeedbackDelegate = delegate;
    
    [_FeedBackTaskV InitStartThread];
}


- (void)CancleSession {
    [_FeedBackTaskV CancleSession];
}

#pragma mark - TaskDelegate

- (void)CallBackBeginError:(NSInteger)result {
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackBeginError:)])
    {
        [self.FeedbackDelegate FeedbackBeginError:result];
    }
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackInitResult:)])
    {
        NSString *initErrorJson = @"{\"operationType\":\"FeedBackBeginError\",\"status\":\"fail\"}";
        [self.FeedbackDelegate FeedbackInitResult:initErrorJson];
    }
}

- (void)CallBackError:(NSInteger)result {
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackError:)])
    {
        [self.FeedbackDelegate FeedbackError:result];
    }
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackResultJson:)]) {
        NSString *errorJson = @"{\"operationType\":\"Feedback\",\"status\":\"fail\",\"data\":{}}";
        [self.FeedbackDelegate FeedbackResultJson:errorJson];
    }
}

- (void)CallBackBeginRecord {
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackBeginRecord)])
    {
        [self.FeedbackDelegate FeedbackBeginRecord];
    }
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackInitResult:)])
    {
        NSString *initErrorJson = @"{\"operationType\":\"FeedbackBeginRecord\",\"status\":\"success\"}";
        [self.FeedbackDelegate FeedbackInitResult:initErrorJson];
    }
}

- (void)CallBackEndRecord {
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackEndRecord)])
    {
        [self.FeedbackDelegate FeedbackEndRecord];
    }
}

- (void)CallBackVolume:(NSInteger)currentvolume {
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackVolume:)])
    {
        [self.FeedbackDelegate FeedbackVolume:currentvolume];
    }
}

- (void)CallBackResult:(VDResultData *)result {
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackResult:)])
    {
        [self.FeedbackDelegate FeedbackResult:result];
    }
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackResultJson:)])
    {
        NSString *keyword = @"[Result]:";
        NSString *resultStr = result.text;
        NSString *resultType = [VcyberTaskUtil checkIsNull:result.type.lowercaseString];
        
        if ([@"end" isEqualToString:resultType])
        {
            NSString *errorJson = @"{\"operationType\":\"Feedback\",\"status\":\"error\",\"data\":{}}";
            [self.FeedbackDelegate FeedbackResultJson:errorJson];
            return;
        }
        
        NSRange range = [resultStr rangeOfString:keyword];
        if(range.length > 0)
        {   // 如果返回结果包含关键字，证明返回结构正确可以进行正常解析，否者返回错误代理
            NSRange range = [resultStr rangeOfString:keyword];
            resultStr = [resultStr substringFromIndex:range.location + range.length];
            NSData *jsonData = [resultStr dataUsingEncoding:NSUTF8StringEncoding];
            NSError *err = nil;
            NSArray *arr = [NSJSONSerialization JSONObjectWithData:jsonData
                                                           options:NSJSONReadingMutableContainers
                                                             error:&err];
            if (!arr || [arr count] <= 0)
            {
                NSString *errorJson = @"{\"operationType\":\"Feedback\",\"status\":\"fail\",\"data\":{}}";
                [self.FeedbackDelegate FeedbackResultJson:errorJson];
                return;
            }
            if (nil != err || !arr || (id)[NSNull null] == arr || nil == arr || [arr count] < 1)
            {   //  如果JSON解析失败证明返回结果有误，需要返回错误代理
                NSString *errorJson = @"{\"operationType\":\"Feedback\",\"status\":\"fail\",\"data\":{}}";
                [self.FeedbackDelegate FeedbackResultJson:errorJson];
            } else {
                id obj = [arr objectAtIndex:0];
                NSString *sucJson = @"{\"operationType\":\"Feedback\",\"status\":\"success\",\"data\":{\"value\":\"%@\",\"Content\":\"%@\"}}";
                NSString *command_name = [VcyberTaskUtil checkIsNull:[obj objectForKey:@"command_name"]];
                NSString *text = [VcyberTaskUtil checkIsNull:[obj objectForKey:@"text"]];
                sucJson = [NSString stringWithFormat:sucJson, command_name, text];
                [self.FeedbackDelegate FeedbackResultJson:sucJson];
            }
        } else {
            NSString *errorJson = @"{\"operationType\":\"Feedback\",\"status\":\"fail\",\"data\":{}}";
            [self.FeedbackDelegate FeedbackResultJson:errorJson];
        }
    }
}

- (void)CallBackFinishAll {
    if ([self.FeedbackDelegate respondsToSelector:@selector(FeedbackFinishAll)])
    {
        [self.FeedbackDelegate FeedbackFinishAll];
    }
}


@end
