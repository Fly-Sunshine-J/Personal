//
//  VDTaskHelper.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/17.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "VDTaskHelper.h"
#import "VDSessionParamsManager.h"
#import "VcyberTaskUtil.h"
#import "TaskController.h"
#import <AVFoundation/AVFoundation.h>

#define O_APP_ID @"cyw00015-1E366C5F-FBE0-4753-17DA-A5569B2D42B5" //小O项目Key

@interface VDTaskHelper ()<TaskDelegate>

@property (nonatomic, weak) id <VDTaskDelegate>TaskVDDelegate;
@property (nonatomic, strong) TaskController *taskV;

@end

@implementation VDTaskHelper

- (instancetype)init {
    if (self = [super init]) {
        [[AVAudioSession sharedInstance] setActive:YES error:nil];
        [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:(AVAudioSessionCategoryOptionMixWithOthers|AVAudioSessionCategoryOptionDefaultToSpeaker) error:nil];
    }
    return self;
}

- (void)beginVDTaskWithDelegate:(id<VDTaskDelegate>)delegate
                      longitude:(double)longitude
                       latitude:(double)latitude
                     isShowView:(bool)isShowView
                         params:(VDSessionParamsManager *)params
{
    VDSessionParamsManager *hash;
    if (params && nil != params && (id)[NSNull null] != params)
    {
        hash = params;
    } else {
        hash = [[VDSessionParamsManager alloc] init];
    }
    
    NSString *userId = [NSString stringWithFormat:@"program:ajx&user:%@&version:ios20160427&poi:%lf,%lf", hash.telNumber, longitude,latitude];
    
    hash.serverUrl = @"http://vdialog.vcyber.com:10006";
    hash.userId = userId;
    hash.appId = O_APP_ID;
    hash.isShowView = isShowView;
    if (hash.audioFormat!=1&&hash.audioFormat!=2) {
        hash.audioFormat = 2;
    }
    
    _taskV = [[TaskController alloc] initWithSessionParam:hash];
    _taskV.delegate = self;
    
    self.TaskVDDelegate = delegate;
    
    [_taskV InitStartThread];
}

- (void)CancleSession {
    [_taskV CancleSession];
}

#pragma mark - TaskDelegate
#pragma mark -

- (void)CallBackBeginError:(NSInteger)result {
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskBeginError:)]) {
        [self.TaskVDDelegate VDTaskBeginError:result];
    }
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskInitResult:)])
    {
        NSString *initErrorJson = @"{\"operationType\":\"VDTaskBeginError\",\"status\":\"fail\"}";
        [self.TaskVDDelegate VDTaskInitResult:initErrorJson];
    }
}

- (void)CallBackError:(NSInteger)result {
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskError:)])
    {
        [self.TaskVDDelegate VDTaskError:result];
    }
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskResultJson:)])
    {
        NSString *errorJson = @"{\"operationType\":\"VDTask\",\"status\":\"fail\",\"data\":{}}";
        [self.TaskVDDelegate VDTaskResultJson:errorJson];
    }
}

- (void)CallBackBeginRecord {
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskBeginRecord)])
    {
        [self.TaskVDDelegate VDTaskBeginRecord];
    }
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskInitResult:)])
    {
        NSString *initErrorJson = @"{\"operationType\":\"VDTaskBeginRecord\",\"status\":\"success\"}";
        [self.TaskVDDelegate VDTaskInitResult:initErrorJson];
    }
}

- (void)CallBackEndRecord {
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskEndRecord)])
    {
        [self.TaskVDDelegate VDTaskEndRecord];
    }
}

- (void)CallBackVolume:(NSInteger)currentvolume {
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskVolume:)])
    {
        [self.TaskVDDelegate VDTaskVolume:currentvolume];
    }
}

- (void)CallBackResult:(VDResultData *)result {
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskResult:)])
    {
        [self.TaskVDDelegate VDTaskResult:result];
    }
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskResultJson:)])
    {
        NSString *keyword = @"[Result]:";
        NSString *resultStr = result.text;
        NSString *resultType = [VcyberTaskUtil changeType:[VcyberTaskUtil checkIsNull:result.type.lowercaseString]];
        
        NSLog(@"resultStr = %@", resultStr);
        if ([@"end" isEqualToString:resultType])
        {
            NSString *errorJson = @"{\"operationType\":\"\",\"status\":\"error\",\"data\":{}}";
            [self.TaskVDDelegate VDTaskResultJson:errorJson];
            return;
        }
        
        NSRange range = [resultStr rangeOfString:keyword];
        if(range.length > 0)
        {   // 如果返回结果包含关键字，证明返回结构正确可以进行正常解析，否者返回错误代理
            NSRange range = [resultStr rangeOfString:keyword];
            resultStr = [resultStr substringFromIndex:range.location + range.length];
            NSData *jsonData = [resultStr dataUsingEncoding:NSUTF8StringEncoding];
            NSError *err = nil;
            NSArray *arr = [NSJSONSerialization JSONObjectWithData:jsonData
                                                           options:NSJSONReadingMutableContainers
                                                             error:&err];
            if (nil != err || !arr || (id)[NSNull null] == arr || nil == arr || [arr count] < 1)
            {   //  如果JSON解析失败证明返回结果有误，需要返回错误代理
                NSString *errorJson = @"{\"operationType\":\"%@\",\"status\":\"fail\",\"data\":{}}";
                errorJson = [NSString stringWithFormat:errorJson, [VcyberTaskUtil changeType:resultType]];
                [self.TaskVDDelegate VDTaskResultJson:errorJson];
            } else {
                id obj = [arr objectAtIndex:0];
                NSString *sucJson = @"";
                NSString *value = @"";
                NSString *poiName = @"";
                NSString *content = @"";
                if ([@"POI" isEqualToString:resultType])
                {
                    sucJson = @"{\"operationType\":\"%@\",\"status\":\"success\",\"data\":{\"value\":\"%@\",\"POIName\":\"%@\",\"Content\":\"%@\"}}";
                    value = [VcyberTaskUtil changePOIType:[VcyberTaskUtil checkIsNull:[obj objectForKey:@"poi_type"]]];
                    poiName = [VcyberTaskUtil checkIsNull:[obj objectForKey:@"poi_name"]];
                    content = [VcyberTaskUtil checkIsNull:[obj objectForKey:@"text"]];
                    sucJson = [NSString stringWithFormat:sucJson, resultType, value, poiName, content];
                }  else if ([@"Command" isEqualToString:resultType]) {
                    sucJson = @"{\"operationType\":\"%@\",\"status\":\"success\",\"data\":{\"value\":\"%@\",\"Content\":\"%@\"}}";
                    value = [VcyberTaskUtil checkIsNull:[obj objectForKey:@"command_name"]];
                    content = [VcyberTaskUtil checkIsNull:[obj objectForKey:@"text"]];
                    sucJson = [NSString stringWithFormat:sucJson, resultType, value, content];
                } else {
                    sucJson = @"{\"operationType\":\"%@\",\"status\":\"success\",\"data\":{}}";
                    sucJson = [NSString stringWithFormat:sucJson, resultType];
                }
                
                [self.TaskVDDelegate VDTaskResultJson:sucJson];
            }
        } else {
            NSString *errorJson = @"{\"operationType\":\"%@\",\"status\":\"fail\",\"data\":{}}";
            errorJson = [NSString stringWithFormat:errorJson, [VcyberTaskUtil changeType:resultType]];
            [self.TaskVDDelegate VDTaskResultJson:errorJson];
        }
    }
}

- (void)CallBackFinishAll {
    if ([self.TaskVDDelegate respondsToSelector:@selector(VDTaskFinishAll)])
    {
        [self.TaskVDDelegate VDTaskFinishAll];
    }
}


@end
