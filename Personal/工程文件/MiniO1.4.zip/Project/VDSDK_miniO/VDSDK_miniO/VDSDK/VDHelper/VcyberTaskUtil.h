//
//  VcyberTaskUtil.h
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/17.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VcyberTaskUtil : NSObject

+ (NSString *)changeType:(NSString *)type; //请求类型转换
+ (id)checkIsNull:(id)str; //检测对象是否为空
+ (NSString *)changePOIType:(NSString *)type; //POI类型转换


@end
