//
//  AudioUtil.m
//  NewerVDSDK
//
//  Created by dengweihao on 16/3/11.
//  Copyright © 2016年 dengweihao. All rights reserved.
//

#import "AudioUtil.h"
#include "tsilk.h"

static AudioUtil *_instance;

@implementation AudioUtil

#pragma mark - Use tsilk encode or dcode audio PCM data
#pragma mark -

+ (int)tsilkEncodeAudio:(NSData *)audio  encodedData:(NSData **)encodedData samplingRate:(NSInteger)hz level:(NSInteger)level
{
    const void * src = (const void *)[audio bytes];
    int src_len = (int)[audio length];
    void * encoded = malloc(src_len);
    int dst_len = src_len;
    
    int encodeRstCode = tsilk_encode_vcyber(src, src_len, encoded, dst_len, (int)hz, (int)level);
    
    int rst = 1;
    if (encodeRstCode != 0 && encodeRstCode < src_len) {
        *encodedData = [NSData dataWithBytes:encoded length:encodeRstCode];
        rst = 0;
    }
    free(encoded);
    
    return rst;
}


+ (int)tsilkDecodeAudio:(NSData *)encodData  decodedData:(NSData **)decodedData samplingRate:(NSInteger)hz
{
    const void * src = (const void *)[encodData bytes];
    int src_len = (int)[encodData length];
    int dst_len = src_len * 15;
    void * decoded = malloc(dst_len);
    int decodeRstCode = tsilk_decode_vcyber(src, src_len, decoded, dst_len, (int)hz);
    
    int rst = 1;
    if (decodeRstCode != 0) {
        if (decodeRstCode < dst_len) {
            *decodedData = [NSData dataWithBytes:decoded length:decodeRstCode];
        } else {
            free(decoded);
            decoded = malloc(decodeRstCode);
            tsilk_decode_vcyber(src, src_len, decoded, decodeRstCode, (int)hz);
            *decodedData = [NSData dataWithBytes:decoded length:decodeRstCode];
        }
        rst = 0;
    }
    free(decoded);
    
    return rst;
}


//去掉wav的音频头
+ (NSData *)cutAudioHeaderWithAudio:(NSData *)audio
{
    unsigned char key[4] = {0x64,0x61,0x74,0x61}; //data
    
    NSData *data_key = [NSData dataWithBytes:key length:4]; //data
    
    NSRange searchRange = NSMakeRange(0, audio.length - 1);
    NSRange range = [audio rangeOfData:data_key options:NSDataSearchBackwards range:searchRange];
    if (range.location == NSNotFound) {
        return audio;
    }
    
    NSRange len_range = NSMakeRange(range.location + 4, 4);
    NSData *len_data = [audio subdataWithRange:len_range];
    int audio_len = *(int *)[len_data bytes];
    
    NSRange rstRange = NSMakeRange(len_range.location + 4, audio_len);
    NSData *rstData = [audio subdataWithRange:rstRange];
    
    return rstData;
}

+ (instancetype)sharedInstance
{
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        _instance = [[[self class] alloc] init];
    });
    return _instance;
}

@end
