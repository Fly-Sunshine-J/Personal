//
//  HttpXMLRequest.h
//  ZingVPRFramework
//
//  Created by iMac on 15-2-2.
//  Copyright (c) 2015年 vcyber. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef void(^CallBackBlock)(bool isSuccess,NSData *data,NSString *errorMessage);

@interface VcyberRequestService : NSObject

#pragma mark - 文字转换生成TTS
#pragma mark -
+ (void)textToTTSWithParam:(NSData *)data
                       url:(NSString *)url
                  callBack:(CallBackBlock)callBackBlock;



@end
