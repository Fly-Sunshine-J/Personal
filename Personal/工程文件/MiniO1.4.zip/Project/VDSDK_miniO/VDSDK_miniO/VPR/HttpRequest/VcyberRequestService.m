//
//  HttpXMLRequest.m
//  ZingVPRFramework
//
//  Created by iMac on 15-2-2.
//  Copyright (c) 2015年 vcyber. All rights reserved.
//

#import "VcyberRequestService.h"
#import <UIKit/UIKit.h>

//typedef void (^OneParameterBlock)(id parameter);
//OneParameterBlock recursiveOneParameterBlockVehicle(void (^block)(OneParameterBlock recurse, id parameter))
//{
//    return ^(id parameter){ block(recursiveOneParameterBlockVehicle(block), parameter);
//    };
//};


@implementation VcyberRequestService




#pragma mark - 文字转换生成TTS
#pragma mark -
+ (void)textToTTSWithParam:(NSData *)data
                       url:(NSString *)url
                  callBack:(CallBackBlock)callBackBlock
{    
    NSURLRequest *request = [self getRequestWithUrl:url postData:data];
    
    [self sendAsyncRequest:request callBackBlock:callBackBlock];
}

#pragma mark - 发送异步请求
#pragma mark -
//+ (void)sendAsyncRequest:(NSURLRequest *)request callBackBlock:(CallBackBlock)callback {
//    
//    OneParameterBlock run = recursiveOneParameterBlockVehicle(^(OneParameterBlock recurse, id parameter) {
//        
//        NSNumber *offset = parameter;
////        NSLog(@"--------------- 尝试连接次数: %@ ---------------", offset);
//        
//        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
//        
//        [NSURLConnection sendAsynchronousRequest:request
//                                           queue:[NSOperationQueue mainQueue]
//                               completionHandler:
//         ^(NSURLResponse *response, NSData *data, NSError *connectionError) {
//             [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
//             NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
//             if ( connectionError) {
//                 
//                 /** update at 2016年04月28日11:21:36 */
//                 
//                 if (connectionError.code == -1005)
//                 {
//                     if (offset.intValue >= 5) {
//                         // Tried too many times, so fail
//                         
//                         callback(NO,data,connectionError.localizedDescription);
//                         
//                     } else {
//                         // Failed because of an iOS bug using timed out connections, so try again
////                         NSLog(@"-1005 重新发送请求 block");
//                         recurse(@(offset.intValue+1));
//                     }
//                     return;
//                 } else {
//                     callback(NO,data,connectionError.localizedDescription);
//                 }
//                 return ;
//             }
//             
//             if (httpResponse.statusCode == 200) {
//                 callback(YES,data,nil);
//             }else{
//                 NSString *error = [NSString stringWithFormat:@"http error %ld",(long)httpResponse.statusCode];
//                 callback(NO,data,error);
//             }
//         }];
//        
//        
//    });
//    run(@0);
//}


/** update at 2016年04月28日16:56:59 */

+ (void)sendAsyncRequest:(NSURLRequest *)request callBackBlock:(CallBackBlock)callback {
    
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    
    
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration ephemeralSessionConfiguration]];
        
        NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                
                NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
                if (error) {
                    
                    callback(NO, data, error.localizedDescription);
                    
                    return ;
                }
                
                if (httpResponse.statusCode == 200) {
                    
                    callback(YES,data,nil);
                } else {
                    
                    NSString *error = [NSString stringWithFormat:@"http error %ld",(long)httpResponse.statusCode];
                    callback(NO,data,error);
                }
                
            });
            
        }];
        
        [task resume];
    });
    
}


#pragma mark - 返回一个request
#pragma mark -
+ (NSURLRequest *)getRequestWithUrl:(NSString *)url postData:(NSData *)data {
    NSTimeInterval timeoutInterval = 30.0f;
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:url]];
    [request setTimeoutInterval:timeoutInterval];
    
    //设置请求header
    [request setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"close" forHTTPHeaderField:@"Connection"];
    
    //设置请求method
    [request setHTTPMethod:@"POST"];
    
    //设置请求的body
    NSData *httpBody = data;
    [request setHTTPBody:httpBody];
    
    
    return request;
}

@end
