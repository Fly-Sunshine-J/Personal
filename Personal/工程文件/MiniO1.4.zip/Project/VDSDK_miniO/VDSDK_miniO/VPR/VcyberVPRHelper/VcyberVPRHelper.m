//
//  VcyberVPRHelper.m
//  ZingVPRFramework
//
//  Created by danhui.quan on 15/2/2.
//  Copyright (c) 2015年 vcyber. All rights reserved.
//

#import "VcyberVPRHelper.h"
#import "VcyberRequestService.h"
#import "AudioUtil.h"
#import "VDGlouble.h"
#import "vcyberEncryptUtil.h"

#define VCYBER_TTSURL @"http://tts.vcyber.com:6002/index.html"

//#define VCYBER_TTSURL @"http://119.90.57.3:6002/index.html"


typedef NS_ENUM(NSInteger, VPRMSG) {
    
    VPRMSG_ZING_NOT_INITIAL = 1,            //ZING VPR SDK声纹内核未初始化
    VPRMSG_ZING_NOT_ENOUGH_MEMORY = 2,      //内存空间不足
    VPRMSG_ZING_NOT_ENOUGH_SPEECH = 3,      //有效音长度不足
    VPRMSG_ZING_BAD_SPEECH_QUALITY = 4,     //语音质量不足
    VPRMSG_ZING_FILE_OPEN_ERR = 101,        //文件打开失败
    VPRMSG_ZING_WAV_FORMAT_ERR = 102,       //WAV文件格式错误
    VPRMSG_ZING_SAMPLERATE_ERR = 103,       //采样率不正确
    VPRMSG_ZING_CMD_FORMAT_ERR = 104,       //批处理命令文件格式错误
    VPRMSG_ZING_FILE_READ_ERR = 105,        //文件读失败
    VPRMSG_ZING_FILE_WRITE_ERR = 106,       //文件写失败
    VPRMSG_ZING_MODEL_FORMAT_ERR = 107,     //VPR模型文件格式错误
    VPRMSG_ZING_NULL_PARAMETER = 201,       //函数指针参数为空
    VPRMSG_ZING_VAL_PARAMETER_ERR = 202,    //函数参数数值范围错误
    VPRMSG_ZING_BUFFER_SIZE_ERR = 203,      //函数参数格式错误
    VPRMSG_ZING_GMM_NOT_INITIAL = 301,      //GMM未初始化
    VPRMSG_ParamInvalid = 1001,             //无效参数
    VPRMSG_DBError = 1002,                  //数据库错误
    VPRMSG_AudioTreatError = 1003,          //音频处理错误
    VPRMSG_UnexpectError = 1004,            //意外错误
    VPRMSG_ModelExist = 1005,               //模型已存在
    VPRMSG_CreateModelFailed = 1006,        //建模失败
    VPRMSG_ModelNotExist = 1007,            //模型不存在
    VPRMSG_VerifyFailed = 1008,             //验证不通过
    VPRMSG_DogError = 1009,                 //加密狗错误
    VPRMSG_MaxThreadLimit = 1010            //已达最大线程数
    
};


@implementation VcyberVPRHelper

- (instancetype)init
{
    if (self = [super init]) {
        
    }
    return self;
}

- (void)dealloc
{
    
}

//文字转为tts
- (void)textToTTSWithText:(NSString *)text callBack:(VPRCallBack)callBack
{
    
    if (!text || [text isKindOfClass:[NSNull class]] || text.length == 0) {
        callBack(NO,nil,@"文本为空");
        return;
    }
    
    NSInteger cps = 7;
    NSInteger fmt = 1;
    
    NSString *url = VCYBER_TTSURL;
    
    //    NSString *paramString = [NSString stringWithFormat:@"{\"type\":\"client\",\"key\":\"CYW00001\",\"obj\":\"8772e2f5b5c11757\",\"fmt\":\"1\",\"cps\":\"7\",\"ecd\":\"1\",\"text\":\"%@\"}",text];
    NSString *paramString = [NSString stringWithFormat:@"{\"type\":\"client\",\"key\":\"CYW00001\",\"obj\":\"8772e2f5b5c11757\",\"fmt\":\"%ld\",\"cps\":\"%ld\",\"ecd\":\"1\",\"text\":\"%@\"}",(long)fmt,(long)cps,text];
    NSData *data = [paramString dataUsingEncoding:NSUTF8StringEncoding];
    
    [VcyberRequestService textToTTSWithParam:data
                                         url:url
                                    callBack:
     ^(bool isSuccess, NSData *data, NSString *errorMessage) {
         if (isSuccess) {
             if (data) {
                 /*
                  {"type":"server",
                  "key":"CYW00001",
                  "obj":"8772e2f5b5c11757",
                  "fmt":"0",
                  "cps":"0",
                  "ecd":"1",
                  "text":"......",
                  "audio”:”base64string”}*/
                 
                 //                  type: client, server
                 //                  *key: 密钥对应的key
                 //                  *obj: 加密后的数据
                 //                  fmt: 0(8Khz x 16bit), 1(16Khz x 16bit)
                 //                  *cps: 压缩等级(0-10), 0为不压缩. skp_silk压缩方式.
                 //                  ecd: 编码方式, 0 gbk, 1 utf8, 对text内容的描述
                 //                  text: 文本(要翻译成音频的文本)
                 //                  audio: 音频数据 base64编码
                 
                 
                 NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data
                                                                          options:NSJSONReadingAllowFragments
                                                                            error:nil];
                 
//                 NSInteger cps = [jsonDict[@"cps"] integerValue];
                 NSInteger fmt = [jsonDict[@"fmt"] integerValue];
                 
                 NSString *pcmString = (NSString *)jsonDict[@"audio"];
                 
                 NSData* encodeData = [[NSData alloc] initWithBase64EncodedString:pcmString options:NSDataBase64DecodingIgnoreUnknownCharacters];
                 
//                 NSData *encodeData = [VcyberGTMBase64 decodeString:pcmString];
                 
                 NSInteger samplingRate = fmt==1?16000:8000;
                 
                 NSData *decodedData = [NSData data];
                 
                 if ([encodeData length] != 0) {
                     
                     int decodedCode = [AudioUtil tsilkDecodeAudio:encodeData decodedData:&decodedData samplingRate:samplingRate];
                     if (decodedCode != 0) {
                         callBack(NO, nil, [NSString stringWithFormat:@"音频解码错误 %d", decodedCode]);
                         return;
                     }
//                     
                 }else{
                     callBack(NO, nil, @"返回音频为空");
                 }
                 
                 int longSampleRate = 8000, byteRate = 16000;
                 if (fmt == 1) {
                     longSampleRate = 16000;
                 }
                 
                 //添加header
                 NSData *audioData = [vcyberEncryptUtil AddHeader:decodedData
                                                         Channels:1
                                                   LongSampleRate:longSampleRate
                                                         ByteRate:byteRate];
                 
                 callBack(YES,audioData,nil);
             }else{
                 callBack(NO,nil,@"返回数据为空");
             }
         }else{
             callBack(NO,nil,errorMessage);
         }
     }];
}


@end





